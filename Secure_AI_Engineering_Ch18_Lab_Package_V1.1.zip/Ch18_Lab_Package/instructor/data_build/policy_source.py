"""Policy library source for the Chapter 18 laboratory.

Alder Valley University is fictional. Every policy, office, number, and
program below is invented for teaching and must not be read as describing
any real institution.

Each section is one retrieval passage. Facts attached to a section generate
evaluation questions (two phrasings, used as separate items only when the
generator needs them) and one retrieval question whose relevant passage is the
section itself. Facts restated in the FAQ document carry the FAQ passage as a
second relevant passage.

Fact tuple: (answer_type, answer, [eval phrasing 1, eval phrasing 2], retrieval question, accepts)
  answer_type: num | yesno | term | code (course code) ; catalog answers are generated separately
  accepts: for term answers, a list of accepted normalized variants
"""

U = "Alder Valley University"

DOCS = []


def doc(doc_id, title, sections):
    DOCS.append({"doc_id": doc_id, "title": title, "sections": sections})


# ---------------------------------------------------------------- withdrawal
doc("WD", "Course Withdrawal Policy", [
    ("WD-01", "Withdrawing from a full-semester course",
     f"Students at {U} may withdraw from a full-semester course through the end of the tenth week of the fall or spring semester. "
     "A withdrawal is requested in the student portal and takes effect on the day it is submitted. Withdrawn courses appear on the transcript "
     "with a grade of W, which does not affect the grade point average. Instructor approval is not required, but students are encouraged to "
     "speak with their advisor first because withdrawal can affect financial aid and full-time status.",
     [("num", 10, ["Through the end of which week of the semester may a student withdraw from a full-semester course?",
                    "What is the last week of the fall or spring semester in which a full-semester course can be withdrawn?"],
       "What's the deadline to drop a full semester class with a W?", None),
      ("yesno", "no", ["Does a W grade affect a student's grade point average?",
                       "Is a grade of W included in the GPA calculation?"],
       "Will a W hurt my GPA?", None),
      ("yesno", "no", ["Is instructor approval required to withdraw from a course?",
                       "Must the instructor approve a course withdrawal?"],
       "Do I need my professor's permission to withdraw from a class?", None)]),
    ("WD-02", "Withdrawing from a half-semester course",
     "Courses that meet for only the first or second half of a semester follow a shorter schedule. A student may withdraw from a "
     "half-semester course through the end of the fifth week of that course. The same W grade rules apply. Summer sessions publish their "
     "own withdrawal dates in the summer schedule, and those dates are not calculated from this policy.",
     [("num", 5, ["Through the end of which week of the course may a student withdraw from a half-semester course?",
                   "What is the withdrawal deadline, in weeks of the course, for a half-semester course?"],
       "When is the last day to withdraw from an eight-week course?", None)]),
    ("WD-03", "Limit on course withdrawals",
     "Undergraduates may withdraw from no more than six courses during their enrollment at the university. Withdrawals approved as part of a "
     "medical, military, or complete withdrawal do not count toward this limit. Once the limit is reached, a student who stops attending a "
     "course receives the grade earned.",
     [("num", 6, ["How many course withdrawals may an undergraduate make during their enrollment?",
                   "What is the maximum number of courses an undergraduate can withdraw from at the university?"],
       "Is there a cap on how many classes I can withdraw from?", None),
      ("yesno", "no", ["Do withdrawals approved as part of a medical withdrawal count toward the course withdrawal limit?",
                       "Is a medical withdrawal counted against the limit on course withdrawals?"],
       "Does a medical withdrawal use up one of my allowed withdrawals?", None)]),
    ("WD-04", "Withdrawing from all courses",
     "A student who wishes to leave every course in a semester requests a complete withdrawal through the Office of the Registrar. A complete "
     "withdrawal may be requested through the last day of classes. Tuition is refunded according to the tuition refund schedule, and "
     "students who receive federal aid should expect a return-of-funds calculation by the Office of Financial Aid.",
     [("term", "Office of the Registrar", ["Which office processes a complete withdrawal from all courses?",
                                          "Through which office does a student request a complete withdrawal?"],
       "Who do I contact to withdraw from all my classes this semester?", ["registrar"]),
      ("term", "last day of classes", ["Until when in the semester may a complete withdrawal be requested?",
                                       "What is the latest point in the semester at which a complete withdrawal can be requested?"],
       "How late in the term can I withdraw from the university entirely?", ["last day of classes"])]),
])

doc("MW", "Medical Withdrawal Policy", [
    ("MW-01", "Purpose and eligibility",
     "A medical withdrawal allows a student whose serious physical or mental health condition prevents completion of the semester to withdraw "
     "from all courses without academic penalty. Medical withdrawals are reviewed by the Office of the Dean of Students, not by individual "
     "instructors, and the student's diagnosis is not shared with faculty.",
     [("term", "Office of the Dean of Students", ["Which office reviews requests for medical withdrawal?",
                                                 "Who reviews a medical withdrawal request?"],
       "Who decides whether I get a medical withdrawal?", ["dean of students"]),
      ("yesno", "no", ["Is the student's diagnosis shared with faculty during a medical withdrawal?",
                       "Do instructors learn the student's diagnosis when a medical withdrawal is approved?"],
       "Will my professors find out what my medical condition is if I take a medical withdrawal?", None)]),
    ("MW-02", "Documentation and timing",
     "Requests must include documentation from a licensed provider stating that the condition prevented continued enrollment. A request may be "
     "submitted retroactively for a semester that ended no more than one year before the request. Requests for earlier semesters are not "
     "considered except through the academic renewal process.",
     [("num", 1, ["How many years after the end of a semester may a retroactive medical withdrawal be requested?",
                   "Up to how many years back may a medical withdrawal be requested retroactively?"],
       "Can I get a medical withdrawal for last year's semester after the fact?", None)]),
    ("MW-03", "Tuition and return",
     "An approved medical withdrawal results in a tuition credit of 50 percent of the semester's tuition when the withdrawal is effective after "
     "the refund schedule has ended. Before returning, the student submits a clearance statement from a provider to the Office of the Dean of "
     "Students at least 30 days before the first day of the term of return.",
     [("num", 50, ["What percentage tuition credit does an approved medical withdrawal provide after the refund schedule has ended?",
                    "After the refund schedule has ended, what percent of tuition is credited for an approved medical withdrawal?"],
       "Do I get any tuition back with a late medical withdrawal?", None),
      ("num", 30, ["How many days before the term of return must a clearance statement be submitted after a medical withdrawal?",
                    "At least how many days before returning must a student submit the provider clearance statement?"],
       "What do I need to do to come back after a medical withdrawal?", None)]),
])

doc("ML", "Military Withdrawal Policy", [
    ("ML-01", "Withdrawal for military service",
     "A student called to active military duty may withdraw from some or all courses at any point in the semester and receive a full refund of "
     "tuition for withdrawn courses. Alternatively, the student may request incomplete grades if at least 75 percent of the semester has been "
     "completed. Students provide a copy of their orders to the Office of Veteran and Military Services.",
     [("yesno", "yes", ["Does a student called to active duty receive a full tuition refund for withdrawn courses?",
                        "Is tuition fully refunded when a student withdraws because of a call to active military duty?"],
       "I got deployment orders mid-semester. Do I get my tuition back?", None),
      ("num", 75, ["What percentage of the semester must be completed for a deployed student to request incomplete grades instead of withdrawing?",
                    "At least what percent of the semester must be finished before a student called to duty can take incompletes?"],
       "Can I take incompletes instead of withdrawing if I'm deployed late in the semester?", None),
      ("term", "Office of Veteran and Military Services", ["To which office does a student called to active duty provide a copy of their orders?",
                                                           "Where are military orders submitted for a military withdrawal?"],
       "Where do I send my military orders?", ["veteran and military services"])]),
])

doc("LV", "Leave of Absence Policy", [
    ("LV-01", "Requesting a leave of absence",
     "An undergraduate in good standing may request a leave of absence for personal, family, financial, or health reasons. A leave lasts one "
     "or two consecutive fall or spring semesters. Requests are submitted to the Office of the Registrar before the first day of the first "
     "semester of the leave.",
     [("num", 2, ["What is the maximum number of consecutive fall or spring semesters a leave of absence may last?",
                   "How many consecutive semesters can a leave of absence cover at most?"],
       "How long can I take a leave of absence?", None),
      ("term", "before the first day", ["When must a leave of absence request be submitted relative to the semester of the leave?",
                                        "By what point must a student submit a leave of absence request?"],
       "When do I have to apply for a leave of absence?", ["before the first day"])]),
    ("LV-02", "Effect of an approved leave",
     "Semesters on an approved leave of absence do not count as a break in enrollment for catalog rights or readmission. A student returning "
     "from an approved leave re-enrolls through the normal registration process and does not submit a readmission application. A student who "
     "does not return when the leave ends is treated as having left the university at the start of the leave.",
     [("yesno", "no", ["Does a student returning from an approved leave of absence submit a readmission application?",
                       "Must a student coming back from an approved leave apply for readmission?"],
       "Do I have to reapply when my leave of absence ends?", None),
      ("yesno", "no", ["Do semesters on an approved leave of absence count as a break in enrollment for catalog rights?",
                       "Is time on an approved leave counted as a break in enrollment for catalog purposes?"],
       "Will taking a leave change which catalog I'm under?", None)]),
])

# ---------------------------------------------------------- accommodations
doc("AC", "Academic Accommodations Policy", [
    ("AC-01", "Requesting accommodations",
     "Students with disabilities request academic accommodations through the Office of Accessibility Services. The student meets with an "
     "access coordinator, provides documentation of the disability and its effect on learning, and receives an accommodation letter. The "
     "student chooses which instructors receive the letter each semester.",
     [("term", "Office of Accessibility Services", ["Through which office do students request academic accommodations?",
                                                   "Which office issues accommodation letters?"],
       "Where do I go to get accommodations for a disability?", ["accessibility services"]),
      ("yesno", "yes", ["Does the student choose which instructors receive the accommodation letter?",
                        "Is it the student who decides which instructors get the accommodation letter?"],
       "Do all my professors automatically get my accommodation letter?", None)]),
    ("AC-02", "Testing accommodations",
     "Students approved for testing accommodations schedule each exam with the testing center at least five business days before the exam. "
     "Final exams must be scheduled at least ten business days before the exam. Instructors provide the exam to the testing center by the "
     "day before it is given.",
     [("num", 5, ["At least how many business days before an exam must a student schedule it with the testing center?",
                   "How many business days in advance must a regular exam be scheduled with the testing center?"],
       "How far ahead do I need to book a test at the testing center?", None),
      ("num", 10, ["At least how many business days before a final exam must it be scheduled with the testing center?",
                    "How many business days of notice are required to schedule a final exam with the testing center?"],
       "How early do I schedule my final at the testing center?", None)]),
    ("AC-03", "Temporary conditions",
     "Students with temporary conditions, such as a broken arm or recovery from surgery, may receive short-term accommodations. Temporary "
     "accommodations last up to eight weeks and may be renewed once with updated documentation.",
     [("num", 8, ["For up to how many weeks do temporary accommodations last?",
                   "What is the maximum length, in weeks, of a temporary accommodation before renewal?"],
       "I broke my wrist. Can I get accommodations for a few weeks?", None),
      ("num", 1, ["How many times may temporary accommodations be renewed?",
                   "Temporary accommodations may be renewed how many times?"],
       "Can a temporary accommodation be extended?", None)]),
    ("AC-04", "Appealing an accommodation decision",
     "A student who disagrees with an accommodation decision may appeal to the Accessibility Appeals Committee within fifteen business days of "
     "the decision. The committee decides within ten business days. Accommodation records are kept by the Office of Accessibility Services and "
     "are not part of the academic record.",
     [("num", 15, ["Within how many business days must a student appeal an accommodation decision?",
                    "How many business days does a student have to appeal an accommodation decision?"],
       "My accommodation request was denied. How do I appeal?", None),
      ("yesno", "no", ["Are accommodation records part of the academic record?",
                       "Do accommodation records become part of a student's academic record?"],
       "Will my accommodations show up on my transcript?", None)]),
])

# ------------------------------------------------------------------ conduct
doc("SC", "Student Conduct Procedures", [
    ("SC-01", "Reports and notice",
     "Any member of the community may report suspected misconduct to the Office of Student Conduct. When the office decides to proceed, it "
     "sends the student written notice of the allegation within ten business days of receiving the report. The notice states the policy "
     "allegedly violated and the date of an initial meeting.",
     [("num", 10, ["Within how many business days of a report does the Office of Student Conduct send written notice of an allegation?",
                    "How many business days does the conduct office have to send notice after receiving a report?"],
       "How soon will I be told if someone reports me for a conduct violation?", None),
      ("term", "Office of Student Conduct", ["To which office is suspected student misconduct reported?",
                                            "Which office receives reports of student misconduct?"],
       "Where do I report another student's misconduct?", ["student conduct"])]),
    ("SC-02", "Hearings",
     "If the matter is not resolved informally, it is heard by a conduct panel of three members: one faculty member, one staff member, and one "
     "student. The standard of evidence is preponderance of the evidence. The student may bring one advisor of their choice, who may consult "
     "with the student but may not speak for them.",
     [("num", 3, ["How many members sit on a student conduct panel?",
                   "A conduct hearing panel is made up of how many members?"],
       "Who decides my conduct case at a hearing?", None),
      ("term", "preponderance of the evidence", ["What standard of evidence is used in student conduct hearings?",
                                                 "Conduct hearings decide cases under what standard of evidence?"],
       "How much proof do they need to find me responsible?", ["preponderance"]),
      ("yesno", "no", ["May a student's advisor speak for the student at a conduct hearing?",
                       "Is the advisor of choice permitted to speak on the student's behalf at a hearing?"],
       "Can my advisor talk for me at the hearing?", None)]),
    ("SC-03", "Appeals",
     "A student may appeal a conduct decision within five business days on one of three grounds: a procedural error that affected the outcome, "
     "new information that was not available at the hearing, or a sanction substantially disproportionate to the violation. Appeals are "
     "decided by the Dean of Students or a designee.",
     [("num", 5, ["Within how many business days may a student appeal a conduct decision?",
                   "How many business days does a student have to file a conduct appeal?"],
       "How long do I have to appeal a conduct decision?", None),
      ("num", 3, ["On how many grounds may a conduct decision be appealed?",
                   "How many permitted grounds for appeal of a conduct decision are there?"],
       "What are valid reasons to appeal a conduct finding?", None)]),
    ("SC-04", "Interim measures",
     "While a matter is pending, the Dean of Students may impose interim measures such as a no-contact directive or a change in housing "
     "assignment when needed to protect safety. Interim measures are not sanctions and are reviewed at least every thirty days.",
     [("yesno", "no", ["Are interim measures considered sanctions?",
                       "Is an interim measure such as a no-contact directive a sanction?"],
       "Is a no-contact order a punishment?", None),
      ("num", 30, ["At least how often, in days, are interim measures reviewed?",
                    "Interim measures are reviewed at least every how many days?"],
       "How long does an interim no-contact directive last?", None)]),
])

doc("AI", "Academic Integrity Policy", [
    ("AI-01", "First violations",
     "An instructor who believes a student has violated academic integrity meets with the student and may resolve a first violation with a "
     "course-level sanction, such as a zero on the assignment. The instructor reports every resolved violation to the Academic Integrity "
     "Board, which keeps a confidential record.",
     [("term", "Academic Integrity Board", ["To which body do instructors report resolved academic integrity violations?",
                                           "Who keeps the confidential record of academic integrity violations?"],
       "If my professor gives me a zero for cheating, does anyone else find out?", ["academic integrity board"])]),
    ("AI-02", "Repeat violations and appeals",
     "A second reported violation is referred to the Academic Integrity Board for a hearing, and the board may impose university-level "
     "sanctions, including suspension. A student may appeal an instructor's finding to the department chair within ten business days.",
     [("term", "department chair", ["To whom may a student appeal an instructor's academic integrity finding?",
                                    "Who hears a student's appeal of an instructor's integrity finding?"],
       "How do I contest a cheating accusation from my instructor?", ["department chair", "chair"]),
      ("num", 10, ["Within how many business days may a student appeal an instructor's academic integrity finding?",
                    "How many business days does a student have to appeal an instructor's integrity finding?"],
       "Is there a deadline to appeal a plagiarism finding?", None)]),
])

# ---------------------------------------------------------- academic records
doc("GA", "Grade Appeal Policy", [
    ("GA-01", "Grounds and timing",
     "A student may appeal a final course grade believed to result from an error in calculation or from standards applied differently than "
     "to other students in the course. The appeal must begin within thirty calendar days after the first day of the next fall or spring "
     "semester. The student first discusses the grade with the instructor, then with the department chair, and finally with the college dean.",
     [("num", 30, ["Within how many calendar days after the start of the next semester must a grade appeal begin?",
                    "How many calendar days into the next fall or spring semester does a student have to start a grade appeal?"],
       "How long do I have to appeal a final grade?", None),
      ("term", "college dean", ["Who is the final step in the grade appeal process?",
                                "After the department chair, to whom does a grade appeal go?"],
       "Who has the final say on a grade appeal?", ["dean"])]),
])

doc("AS", "Academic Standing Policy", [
    ("AS-01", "Good standing and probation",
     "Students are in good academic standing when their cumulative grade point average is 2.0 or higher. A student whose cumulative grade point "
     "average falls below 2.0 is placed on academic probation for the next fall or spring semester and must meet with an advisor before "
     "registering.",
     [("yesno", "yes", ["Must a student on academic probation meet with an advisor before registering?",
                        "Is a meeting with an advisor required before a student on probation registers?"],
       "What happens if my GPA drops too low?", None)]),
    ("AS-02", "Suspension and reinstatement",
     "A student who remains below a 2.0 cumulative grade point average after two consecutive semesters on probation is academically suspended "
     "for one fall or spring semester. After the suspension, the student may apply for reinstatement. A second suspension results in academic "
     "dismissal, and a dismissed student may apply for readmission only through academic renewal.",
     [("num", 2, ["After how many consecutive semesters on probation below a 2.0 is a student suspended?",
                   "How many consecutive probation semesters below 2.0 lead to academic suspension?"],
       "How many semesters can I be on probation before I get suspended?", None),
      ("term", "academic dismissal", ["What is the result of a second academic suspension?",
                                      "A second academic suspension leads to what outcome?"],
       "What happens if I get suspended twice?", ["dismissal"])]),
])

doc("RP", "Course Repeat Policy", [
    ("RP-01", "Repeating a course",
     "A student may attempt a course no more than three times. When a course is repeated, only the most recent grade is used in the grade "
     "point average, even if it is lower, and all attempts remain on the transcript. Courses designated as repeatable for credit, such as "
     "ensemble or special-topics courses, are not subject to this policy.",
     [("num", 3, ["What is the maximum number of times a student may attempt a course?",
                   "How many attempts at the same course are allowed?"],
       "How many times can I retake a class?", None),
      ("term", "most recent grade", ["When a course is repeated, which grade is used in the grade point average?",
                                     "Which attempt's grade counts in the GPA after a repeat?"],
       "If I retake a class, does the better grade count?", ["most recent"])]),
])

doc("IN", "Incomplete Grade Policy", [
    ("IN-01", "Incomplete grades",
     "An instructor may assign a grade of I when a student has completed most of the course but cannot finish because of circumstances beyond "
     "the student's control. The remaining work must be completed by the end of the next fall or spring semester. An incomplete not completed "
     "by then converts to a grade of F.",
     [("term", "F", ["What grade does an unresolved incomplete convert to?",
                     "If the work for an incomplete is not finished in time, what grade results?"],
       "What happens if I don't finish an incomplete?", ["f"]),
      ("term", "end of the next fall or spring semester", ["By when must the remaining work for an incomplete be completed?",
                                                            "What is the deadline for finishing incomplete coursework?"],
       "How long do I have to finish an incomplete?", ["next fall or spring semester", "end of the next semester", "next semester"])]),
])

doc("PF", "Pass/Fail Option", [
    ("PF-01", "Electing pass/fail",
     "Students may take up to twelve credits of elective courses on a pass/fail basis. Courses required for the major or minor may not be "
     "taken pass/fail. The pass/fail election must be made by the end of the fourth week of the semester and cannot be reversed. A grade of P "
     "requires work equivalent to a C or better.",
     [("num", 12, ["Up to how many credits may a student take pass/fail?",
                    "What is the maximum number of pass/fail credits a student can take?"],
       "How many classes can I take pass/fail?", None),
      ("num", 4, ["By the end of which week must the pass/fail election be made?",
                   "What is the last week of the semester to elect pass/fail?"],
       "When is the deadline to switch a class to pass/fail?", None),
      ("yesno", "no", ["May courses required for the major be taken pass/fail?",
                       "Can a major requirement be taken on a pass/fail basis?"],
       "Can I take a class for my major pass/fail?", None)]),
])

doc("TC", "Transfer Credit Policy", [
    ("TC-01", "Accepted coursework",
     "The university accepts transfer credit for college-level courses completed at regionally accredited institutions with a grade of C or "
     "better. Transfer grades are not included in the grade point average. A maximum of 64 credits may be transferred from community colleges, "
     "and a maximum of 90 credits from all institutions combined.",
     [("num", 64, ["What is the maximum number of credits that may be transferred from community colleges?",
                    "How many community college credits can be transferred at most?"],
       "How many credits from my community college will transfer?", None),
      ("num", 90, ["What is the maximum number of transfer credits from all institutions combined?",
                    "How many total transfer credits may be accepted from all institutions?"],
       "What's the most transfer credit I can bring in overall?", None),
      ("yesno", "no", ["Are transfer grades included in the grade point average?",
                       "Do grades from transferred courses count in the GPA?"],
       "Do my transfer grades count toward my GPA here?", None)]),
    ("TC-02", "Transfer Block",
     "Students who complete the Alder Valley Transfer Block at a partner community college with a grade of C or better in each course satisfy "
     "the university's general education requirements, except for the upper-level writing course, which must be completed at the university.",
     [("term", "upper-level writing course", ["Which general education requirement is not satisfied by completing the Transfer Block?",
                                              "After the Transfer Block, which general education course must still be taken at the university?"],
       "Does finishing the Transfer Block cover all my gen eds?", ["upper level writing"])]),
    ("TC-03", "Residency requirement",
     "To earn a bachelor's degree, a student must complete at least 30 credits at the university, including at least 15 of the final 30 credits "
     "applied to the degree.",
     [("num", 30, ["What is the minimum number of credits a student must complete at the university to earn a bachelor's degree?",
                    "How many credits must be earned at the university for a bachelor's degree?"],
       "How many credits do I have to take here to graduate?", None),
      ("num", 15, ["How many of the final 30 credits must be completed at the university?",
                    "Of the last 30 credits applied to the degree, how many must be earned at the university?"],
       "Can I take my last semester somewhere else and transfer it back?", None)]),
])

doc("CE", "Credit by Examination", [
    ("CE-01", "Advanced Placement and CLEP",
     "The university awards credit for Advanced Placement examinations with a score of 3 or higher and for CLEP examinations at the score "
     "recommended by the American Council on Education. A student may apply no more than 30 credits earned by examination to a degree. Credit "
     "by examination carries no grade.",
     [("num", 3, ["What minimum Advanced Placement score earns credit?",
                   "An AP exam score of at least what earns university credit?"],
       "What AP score do I need to get credit?", None),
      ("num", 30, ["What is the maximum number of credits earned by examination that may be applied to a degree?",
                    "How many credits by examination can count toward a degree at most?"],
       "Is there a limit on AP and CLEP credit?", None)]),
])

doc("RG", "Registration and Course Load", [
    ("RG-01", "Course load",
     "A full-time undergraduate load is 12 or more credits in a fall or spring semester. Enrollment in more than 18 credits is an overload and "
     "requires a cumulative grade point average of at least 3.0 and approval from the student's advisor.",
     [("num", 12, ["What is the minimum number of credits for full-time undergraduate status in a fall or spring semester?",
                    "How many credits make a full-time undergraduate load?"],
       "How many credits do I need to be full time?", None),
      ("num", 18, ["Enrollment in more than how many credits is considered an overload?",
                    "Above how many credits does a semester load count as an overload?"],
       "Can I take 21 credits next semester?", None)]),
    ("RG-02", "Adding and dropping courses",
     "Students may add courses through the end of the first week of the semester. A course dropped by the end of the second week does not "
     "appear on the transcript. After the second week, leaving a course is a withdrawal and follows the course withdrawal policy.",
     [("num", 1, ["Through the end of which week may students add courses?",
                   "What is the last week of the semester in which a course can be added?"],
       "Is it too late to add a class in week two?", None),
      ("num", 2, ["By the end of which week must a course be dropped for it not to appear on the transcript?",
                   "Through which week can a course be dropped without any transcript record?"],
       "If I drop a class early, will it show on my transcript?", None)]),
])

doc("TR", "Tuition Refund Schedule", [
    ("TR-01", "Full-semester refund schedule",
     "Tuition for full-semester courses is refunded as follows when a student drops or withdraws: 100 percent through the fifth day of classes, "
     "50 percent from the sixth through the tenth day, and 25 percent from the eleventh through the twentieth day. No refund is given after "
     "the twentieth day of classes. Fees are not refundable after the fifth day.",
     [("num", 100, ["What percentage of tuition is refunded for a drop through the fifth day of classes?",
                     "Through the fifth day of classes, what percent of tuition is refunded?"],
       "If I drop on the first day, do I get all my money back?", None),
      ("num", 25, ["What percentage of tuition is refunded from the eleventh through the twentieth day of classes?",
                    "What percent refund applies between the eleventh and twentieth day of classes?"],
       "How much do I get back if I withdraw in the third week?", None),
      ("num", 20, ["After which day of classes is no tuition refund given?",
                    "No tuition refund is given after what day of classes?"],
       "When do tuition refunds stop?", None)]),
])

doc("GR", "Graduation", [
    ("GR-01", "Applying to graduate",
     "Students apply for graduation through the student portal by the end of the third week of the semester in which they intend to finish. "
     "A degree audit showing all requirements complete or in progress is required before the application is approved.",
     [("num", 3, ["By the end of which week of the final semester must students apply for graduation?",
                   "What is the deadline week for submitting a graduation application?"],
       "When do I apply to graduate?", None)]),
    ("GR-02", "Latin honors",
     "Graduation honors are based on the cumulative grade point average of credits earned at the university: cum laude for 3.5, magna cum laude "
     "for 3.7, and summa cum laude for 3.9. Students must complete at least 45 credits at the university to be eligible for honors.",
     [("term", "magna cum laude", ["Which graduation honor is awarded for a cumulative GPA of 3.7?",
                                   "What honor does a 3.7 cumulative grade point average earn at graduation?"],
       "What GPA do I need for magna cum laude?", ["magna cum laude"]),
      ("num", 45, ["How many credits must be completed at the university to be eligible for graduation honors?",
                    "What is the minimum number of university credits for honors eligibility?"],
       "Can transfer students graduate with honors?", None)]),
])

doc("DM", "Double Majors and Minors", [
    ("DM-01", "Double majors",
     "A student may complete two majors within one bachelor's degree. No more than nine credits may be counted toward both majors. Each major's "
     "minimum grade point average must be met separately.",
     [("num", 9, ["How many credits may be counted toward both majors in a double major?",
                   "What is the maximum number of credits shared between two majors?"],
       "Can classes count for both of my majors?", None)]),
    ("DM-02", "Minors",
     "Minors require between 18 and 24 credits as specified by the department. At least nine credits of the minor must be completed at the "
     "university, and courses for the minor may not be taken pass/fail.",
     [("num", 9, ["How many credits of a minor must be completed at the university?",
                   "At least how many minor credits must be earned at the university?"],
       "Can I transfer in all the classes for my minor?", None),
      ("yesno", "no", ["May courses for a minor be taken pass/fail?",
                       "Can a course counted toward a minor be taken pass/fail?"],
       "Can I take a minor class pass/fail?", None)]),
])

doc("AT", "Attendance and Religious Observance", [
    ("AT-01", "Religious observance",
     "Students who will miss class for religious observance notify their instructors in writing within the first two weeks of the semester. "
     "Instructors provide a reasonable opportunity to make up missed work without penalty.",
     [("num", 2, ["Within the first how many weeks must students notify instructors of absences for religious observance?",
                   "How many weeks into the semester do students have to give notice of religious observance absences?"],
       "I'll miss class for a religious holiday. What should I do?", None)]),
    ("AT-02", "Bereavement",
     "Students who experience the death of a family member may receive up to five consecutive class days of excused absence. The student "
     "notifies the Office of the Dean of Students, which informs the student's instructors.",
     [("num", 5, ["Up to how many consecutive class days of excused absence are available for bereavement?",
                   "How many class days of bereavement absence may be excused?"],
       "My grandmother died. Can I miss class for the funeral?", None),
      ("term", "Office of the Dean of Students", ["Which office does a student notify for a bereavement absence?",
                                                 "Who informs instructors of a student's bereavement absence?"],
       "Who tells my professors I'll be out for a funeral?", ["dean of students"])]),
])

doc("RD", "Readmission", [
    ("RD-01", "Applying for readmission",
     "A former student who has not been enrolled for two or more consecutive fall or spring semesters, and who was not on an approved leave of "
     "absence, applies for readmission through the Office of Admissions at least 30 days before the term of return. Students who attended "
     "another institution while away submit transcripts from that institution.",
     [("term", "Office of Admissions", ["Through which office does a former student apply for readmission?",
                                       "Which office handles readmission applications?"],
       "I left two years ago. How do I come back?", ["admissions"]),
      ("num", 30, ["At least how many days before the term of return must a readmission application be submitted?",
                    "How many days before the return term is the readmission application due?"],
       "Is there a deadline to apply for readmission?", None)]),
])

doc("AR", "Academic Renewal", [
    ("AR-01", "Academic renewal",
     "A student who returns after an absence of at least five years may petition once for academic renewal. If approved, grades earned before "
     "the absence remain on the transcript but are excluded from the grade point average. Courses with a grade of C or better still count "
     "toward degree requirements. The student must complete 12 credits with at least a 2.5 grade point average after returning before the "
     "petition is decided.",
     [("num", 5, ["After an absence of at least how many years may a student petition for academic renewal?",
                   "How many years must a student have been away to be eligible for academic renewal?"],
       "Can my old grades be wiped from my GPA if I've been gone a long time?", None),
      ("num", 12, ["How many credits must a returning student complete before an academic renewal petition is decided?",
                    "Before the academic renewal decision, how many credits must the student complete after returning?"],
       "What do I have to do before academic renewal is approved?", None)]),
])

# ------------------------------------------------------------ catalog editions
# Catalog rights differ by edition. These differences drive the critical category.
CATALOG_RULES = {
    "2023-24": {"break": 3, "partner_years": 3, "valid_years": 8},
    "2024-25": {"break": 2, "partner_years": 3, "valid_years": 8},
    "2025-26": {"break": 2, "partner_years": 2, "valid_years": 6},
}

YEARS = ["2023-24", "2024-25", "2025-26"]


def disp(y):
    return y.replace("-", "–")


for y in YEARS:
    r = CATALOG_RULES[y]
    words = {2: "two", 3: "three"}
    doc(f"CR{y[2:4]}", f"{disp(y)} Undergraduate Catalog: Catalog Rights", [
        (f"CR{y[2:4]}-01", f"Catalog rights in the {disp(y)} catalog",
         f"This section of the {disp(y)} Undergraduate Catalog describes which catalog's degree requirements apply to a student. A student follows "
         "the catalog in effect for the student's first term of enrollment at the university. Each catalog takes effect with the fall semester "
         "and remains in effect through the following summer. A student may instead elect any later catalog in effect while the student is "
         "enrolled, by request through the degree audit office, but must then meet all requirements of the elected catalog. A student may not "
         "elect a catalog earlier than the one assigned.",
         []),
        (f"CR{y[2:4]}-02", f"Breaks in enrollment under the {disp(y)} catalog",
         f"Under the {disp(y)} catalog, a student who is not enrolled for {words[r['break']]} or more consecutive fall or spring semesters, "
         "without an approved leave of absence, follows the catalog in effect for the term of readmission. Summer sessions are not counted "
         "either as enrollment or as absence. Semesters on an approved leave of absence do not count toward a break.",
         [("num", r["break"], [f"Under the {disp(y)} catalog, how many consecutive fall or spring semesters of non-enrollment move a student to the catalog in effect at readmission?",
                               f"In the {disp(y)} catalog, a break of how many consecutive semesters without an approved leave changes a student's catalog?"],
           f"How long can I stop out before I lose my catalog year under the {disp(y)} catalog?", None)]),
        (f"CR{y[2:4]}-03", f"Partner transfer catalog rights under the {disp(y)} catalog",
         f"Under the {disp(y)} catalog, a student who transfers from a partner community college may follow the university catalog that was in "
         "effect when the student first enrolled at the partner college, provided the student enrolls at the university within "
         f"{words[r['partner_years']]} years of that first partner enrollment and had no break of two or more consecutive fall or spring "
         f"semesters at the partner college. Otherwise the student follows the catalog in effect at first enrollment at the university. "
         f"Catalogs in this edition remain valid for {words.get(r['valid_years'], str(r['valid_years']))} years "
         f"from the start of the catalog year; a student who has not graduated by then moves to the current catalog.",
         [("num", r["partner_years"], [f"Under the {disp(y)} catalog, within how many years of first partner enrollment must a transfer student enroll at the university to keep the earlier catalog?",
                                       f"In the {disp(y)} catalog, how many years after starting at a partner college may a student enroll at the university and still follow the catalog from that start?"],
           f"I started at a community college partner. Which catalog do I follow under the {disp(y)} rules?", None),
          ("num", r["valid_years"], [f"For how many years does a catalog remain valid under the {disp(y)} catalog?",
                                     f"In the {disp(y)} catalog, how many years from the start of the catalog year does a catalog stay valid?"],
           f"Does my catalog year ever expire under the {disp(y)} catalog?", None)]),
    ])

# General education by edition
GENED = {"2023-24": 40, "2024-25": 37, "2025-26": 37}
for y in YEARS:
    doc(f"GE{y[2:4]}", f"{disp(y)} Undergraduate Catalog: General Education", [
        (f"GE{y[2:4]}-01", f"General education requirements in the {disp(y)} catalog",
         f"Students following the {disp(y)} catalog complete {GENED[y]} credits of general education distributed across communication, "
         "quantitative reasoning, natural sciences, social sciences, humanities and arts, and an upper-level writing course taken after "
         "earning 60 credits. " + ("The 2024–2025 revision removed the three-credit wellness requirement." if y != "2023-24" else
                                   "This edition includes a three-credit wellness requirement."),
         [("num", GENED[y], [f"How many general education credits are required under the {disp(y)} catalog?",
                              f"Under the {disp(y)} catalog, how many credits of general education must a student complete?"],
           f"How many gen ed credits do I need on the {disp(y)} catalog?", None)]),
    ])

# Programs by edition: (name, code, {year: (total, major, min_major_gpa, capstone, internship)})
PROGRAMS = [
    ("Accounting, B.S.", "ACCT", {"2023-24": (120, 54, "2.5", "ACCT 495", "no"), "2024-25": (120, 54, "2.5", "ACCT 495", "yes"), "2025-26": (120, 57, "2.5", "ACCT 495", "yes")}),
    ("Biology, B.S.", "BIOL", {"2023-24": (120, 48, "2.25", "BIOL 490", "no"), "2024-25": (120, 50, "2.25", "BIOL 490", "no"), "2025-26": (120, 50, "2.5", "BIOL 491", "no")}),
    ("Computer Science, B.S.", "CSCI", {"2023-24": (124, 60, "2.5", "CSCI 498", "no"), "2024-25": (120, 60, "2.5", "CSCI 498", "no"), "2025-26": (120, 63, "2.5", "CSCI 498", "no")}),
    ("Criminal Justice, B.A.", "CRJU", {"2023-24": (120, 42, "2.0", "CRJU 480", "yes"), "2024-25": (120, 42, "2.0", "CRJU 480", "yes"), "2025-26": (120, 45, "2.25", "CRJU 480", "yes")}),
    ("Data Analytics, B.S.", "DATA", {"2023-24": (120, 51, "2.5", "DATA 490", "no"), "2024-25": (120, 54, "2.5", "DATA 495", "yes"), "2025-26": (120, 54, "2.5", "DATA 495", "yes")}),
    ("Elementary Education, B.S.", "EDUC", {"2023-24": (126, 66, "2.75", "EDUC 499", "yes"), "2024-25": (126, 66, "3.0", "EDUC 499", "yes"), "2025-26": (124, 64, "3.0", "EDUC 499", "yes")}),
    ("English, B.A.", "ENGL", {"2023-24": (120, 39, "2.0", "ENGL 490", "no"), "2024-25": (120, 39, "2.0", "ENGL 490", "no"), "2025-26": (120, 36, "2.0", "ENGL 490", "no")}),
    ("Information Security, B.S.", "ISEC", {"2023-24": (120, 57, "2.5", "ISEC 495", "yes"), "2024-25": (120, 60, "2.5", "ISEC 495", "yes"), "2025-26": (120, 60, "2.75", "ISEC 497", "yes")}),
    ("Nursing, B.S.N.", "NURS", {"2023-24": (128, 70, "3.0", "NURS 480", "yes"), "2024-25": (124, 68, "3.0", "NURS 480", "yes"), "2025-26": (124, 68, "3.0", "NURS 485", "yes")}),
    ("Psychology, B.A.", "PSYC", {"2023-24": (120, 40, "2.0", "PSYC 490", "no"), "2024-25": (120, 42, "2.25", "PSYC 490", "no"), "2025-26": (120, 42, "2.25", "PSYC 490", "yes")}),
    ("Social Work, B.S.W.", "SOCW", {"2023-24": (120, 55, "2.5", "SOCW 490", "yes"), "2024-25": (120, 55, "2.5", "SOCW 490", "yes"), "2025-26": (120, 58, "2.75", "SOCW 490", "yes")}),
    ("Mechanical Engineering Technology, B.S.", "MET", {"2023-24": (128, 72, "2.25", "MET 494", "no"), "2024-25": (124, 70, "2.25", "MET 494", "yes"), "2025-26": (124, 70, "2.5", "MET 494", "yes")}),
]

for name, code, yrs in PROGRAMS:
    for y in YEARS:
        tot, maj, gpa, cap, intern = yrs[y]
        intern_s = ("An approved internship of at least 120 hours is required." if intern == "yes"
                    else "An internship is encouraged but not required.")
        doc(f"{code}{y[2:4]}", f"{disp(y)} Undergraduate Catalog: {name}", [
            (f"{code}{y[2:4]}-01", f"{name} requirements in the {disp(y)} catalog",
             f"Under the {disp(y)} catalog, the {name} requires {tot} total credits, including {maj} credits in the major and the general "
             f"education requirements of that catalog. Students must earn a minimum grade point average of {gpa} in major courses. The capstone "
             f"course is {cap}, taken in the final year. {intern_s}",
             [("num", tot, [f"How many total credits does the {name} require under the {disp(y)} catalog?",
                            f"Under the {disp(y)} catalog, what is the total credit requirement for the {name}?"],
               f"How many credits is the {name.split(',')[0]} degree on the {disp(y)} catalog?", None),
              ("num", maj, [f"How many credits in the major does the {name} require under the {disp(y)} catalog?",
                            f"Under the {disp(y)} catalog, how many major credits are required for the {name}?"],
               None, None),
              ("num", float(gpa), [f"What minimum grade point average in major courses does the {name} require under the {disp(y)} catalog?",
                             f"Under the {disp(y)} catalog, what is the minimum major GPA for the {name}?"],
               f"What GPA do I need in my {name.split(',')[0]} courses under the {disp(y)} catalog?", None),
              ("code", cap, [f"What is the capstone course for the {name} under the {disp(y)} catalog?",
                             f"Under the {disp(y)} catalog, which course is the {name} capstone?"],
               None, None),
              ("yesno", intern, [f"Does the {name} require an internship under the {disp(y)} catalog?",
                                 f"Under the {disp(y)} catalog, is an internship required for the {name}?"],
               None, None)]),
        ])

# --------------------------------------------------------------------- FAQ
# Restatements create a second relevant passage for selected retrieval questions.
FAQ = [
    ("FAQ-01", "Can I still withdraw from a class?",
     "Full-semester courses can be withdrawn through the end of the tenth week and half-semester courses through the end of the fifth week of "
     "the course. A W does not affect your GPA, but undergraduates may withdraw from no more than six courses in total.", ["WD-01", "WD-02", "WD-03"]),
    ("FAQ-02", "What if I need to leave for medical reasons?",
     "The Office of the Dean of Students reviews medical withdrawals. You will need documentation from a licensed provider, and you can request "
     "a medical withdrawal for a semester that ended up to one year ago.", ["MW-01", "MW-02"]),
    ("FAQ-03", "How do accommodations work for exams?",
     "Once Accessibility Services approves testing accommodations, schedule each exam with the testing center at least five business days ahead, "
     "or ten business days ahead for finals.", ["AC-02"]),
    ("FAQ-04", "Which catalog am I on?",
     "Most students follow the catalog in effect when they first enrolled. Breaks in enrollment, approved leaves, and transfer from a partner "
     "college can change that, and the rules differ between catalog editions. Confirm your catalog year through a degree audit with your advisor.",
     ["CR23-01", "CR24-01", "CR25-01"]),
    ("FAQ-05", "Will a conduct report go on my record?",
     "If the Office of Student Conduct proceeds with a report, you receive written notice within ten business days. Hearings use the "
     "preponderance-of-the-evidence standard, and you may appeal within five business days.", ["SC-01", "SC-02", "SC-03"]),
    ("FAQ-06", "Can I take time off and come back?",
     "An approved leave of absence lasts one or two semesters, and you return through normal registration without applying for readmission. "
     "If you leave without an approved leave, you apply for readmission through the Office of Admissions.", ["LV-01", "LV-02", "RD-01"]),
]
doc("FAQ", "Policy Questions Students Ask", [(pid, h, t, []) for pid, h, t, _ in FAQ])
FAQ_LINKS = {}
for pid, _, _, links in FAQ:
    for l in links:
        FAQ_LINKS.setdefault(l, []).append(pid)
