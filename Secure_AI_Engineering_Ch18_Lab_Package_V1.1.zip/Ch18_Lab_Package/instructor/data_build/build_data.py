#!/usr/bin/env python3
"""Generate the Chapter 18 laboratory datasets from policy_source.py.

Outputs (written to ../../data/ by default):
  corpus/passages.jsonl          95 passages from 64 fictional policy documents
  eval/catalog_eval.jsonl        300 questions with context passage ids and answer key
  eval/repeatability_subset.txt  20 question ids for the repeatability reruns
  retrieval/questions.jsonl      200 retrieval questions with relevant passage ids

The output is deterministic. Re-running it reproduces the shipped files byte for
byte, which tools/hash_inventory.py can confirm.
"""
import json, math, os, random, re, sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import policy_source as P

OUT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "..", "data"))
SEED = 1818


def w(path, rows):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n")


# ---------------------------------------------------------------- passages
passages = []
facts = []
for d in P.DOCS:
    for pid, head, text, fl in d["sections"]:
        passages.append({"passage_id": pid, "doc_id": d["doc_id"], "doc_title": d["title"],
                         "heading": head, "text": text})
        for i, f in enumerate(fl):
            facts.append({"passage_id": pid, "doc_id": d["doc_id"], "idx": i, "type": f[0], "answer": f[1],
                          "eval_q": f[2], "ret_q": f[3], "accepts": f[4]})
PID = {p["passage_id"]: p for p in passages}
CATDOCS = {f"{k}{y[2:4]}" for k in ("CR", "GE") for y in P.YEARS}
PROGDOCS = {f"{code}{y[2:4]}" for _, code, _ in P.PROGRAMS for y in P.YEARS}

# simple TF-IDF for choosing confusable distractor passages
TOK = re.compile(r"[a-z0-9]+")
STOP = set("the a an of to and or in for is are be by with on at as that this from may must not any who which".split())


def toks(s):
    return [t for t in TOK.findall(s.lower()) if t not in STOP]


df = Counter()
for p in passages:
    df.update(set(toks(p["heading"] + " " + p["text"])))
N = len(passages)


def vec(s):
    c = Counter(toks(s))
    v = {t: (1 + math.log(n)) * math.log(N / df.get(t, 1)) for t, n in c.items() if t in df}
    norm = math.sqrt(sum(x * x for x in v.values())) or 1
    return {t: x / norm for t, x in v.items()}


PV = {p["passage_id"]: vec(p["heading"] + " " + p["text"]) for p in passages}


def sim(a, b):
    return sum(x * b.get(t, 0) for t, x in a.items())


def distractors(gold_ids, k, query):
    qv = vec(query + " " + " ".join(PID[g]["text"] for g in gold_ids))
    ranked = sorted((pid for pid in PID if pid not in gold_ids and not pid.startswith("FAQ")),
                    key=lambda pid: (-sim(qv, PV[pid]), pid))
    return ranked[:k]


def ans_record(f):
    t, a = f["type"], f["answer"]
    if t == "num":
        return {"answer_type": "num", "answer": a, "answer_display": str(a)}
    if t == "yesno":
        return {"answer_type": "yesno", "answer": a, "answer_display": a}
    if t == "code":
        return {"answer_type": "code", "answer": a, "answer_display": a}
    return {"answer_type": "term", "answer": a, "answer_display": a, "accept": f["accepts"] or [a.lower()]}


# --------------------------------------------------------- critical category
SEASON = {"Fall": 0, "Spring": 1, "Summer": 2}


def catalog_for(season, year):
    """Catalog in effect for a term. Each catalog runs fall through the following summer."""
    start = year if season == "Fall" else year - 1
    return f"{start}-{str(start + 1)[2:]}"


def sem_index(season, year):
    """Index over fall/spring semesters only: Fall 2023 = 0, Spring 2024 = 1, ..."""
    assert season in ("Fall", "Spring")
    return (year - 2023) * 2 + (0 if season == "Fall" else -1)


def sem_name(i):
    return ("Fall", 2023 + i // 2) if i % 2 == 0 else ("Spring", 2024 + i // 2)


def fmt(t):
    return f"{t[0]} {t[1]}"


def disp(y):
    return y.replace("-", "–")


rng = random.Random(SEED)
critical = []

# A. breaks in enrollment (20)
breaks = []
for first in range(0, 3):                 # Fall 2023, Spring 2024, Fall 2024
    for gap in (1, 2, 3):
        for leave in (False, True):
            if leave and gap > 2:         # the leave policy allows at most two consecutive semesters
                continue
            for enrolled_for in (1, 2):
                last_enrolled = first + enrolled_for - 1
                readmit = last_enrolled + gap + 1
                if readmit > 5:           # Spring 2026 is the latest term with a catalog in the corpus
                    continue
                breaks.append((first, gap, leave, last_enrolled, readmit))
rng.shuffle(breaks)
for first, gap, leave, last_enrolled, readmit in breaks[:20]:
    t0, t1 = sem_name(first), sem_name(readmit)
    edition = catalog_for(*t1)
    rule = P.CATALOG_RULES[edition]["break"]
    missed = [fmt(sem_name(i)) for i in range(last_enrolled + 1, readmit)]
    missed_s = missed[0] if len(missed) == 1 else ", ".join(missed[:-1]) + (", and " if len(missed) > 2 else " and ") + missed[-1]
    leave_s = "while on an approved leave of absence" if leave else "and did not have an approved leave of absence"
    through = "" if last_enrolled == first else f", stayed enrolled through {fmt(sem_name(last_enrolled))}"
    q = (f"Applying the Catalog Rights policy in the {disp(edition)} catalog: a student first enrolled at the university in {fmt(t0)}{through}, "
         f"was not enrolled in {missed_s} {leave_s}, and returned in {fmt(t1)}. Which catalog year applies to the student?")
    ans = catalog_for(*t1) if (gap >= rule and not leave) else catalog_for(*t0)
    yr = edition[2:4]
    ctx_gold = [f"CR{yr}-01", f"CR{yr}-02"]
    ctx_dis = [f"CR{y[2:4]}-02" for y in P.YEARS if y != edition]
    critical.append({"q": q, "answer": ans, "gold": ctx_gold, "dis": ctx_dis, "scenario": "break",
                     "params": {"first": fmt(t0), "last_enrolled": fmt(sem_name(last_enrolled)), "missed": missed, "approved_leave": leave, "return": fmt(t1), "edition": edition}})

# B. partner transfer (10)
partner_cases = [
    # (partner first term, university first term, break at partner)
    (("Fall", 2023), ("Spring", 2025), False), (("Fall", 2023), ("Spring", 2025), True),
    (("Spring", 2024), ("Fall", 2024), False), (("Spring", 2024), ("Fall", 2024), True),
    (("Fall", 2023), ("Spring", 2026), False), (("Spring", 2024), ("Fall", 2025), False),
    (("Spring", 2024), ("Fall", 2025), True), (("Fall", 2023), ("Fall", 2024), False),
    (("Fall", 2024), ("Spring", 2026), False), (("Fall", 2023), ("Fall", 2025), True),
]
for (ps, py), (us, uy), brk in partner_cases:
    edition = catalog_for(us, uy)
    start = lambda s_, y_: y_ + (0.0 if s_ == "Spring" else 0.67)   # spring starts in January, fall in late August
    yrs = round(start(us, uy) - start(ps, py), 2)
    limit = P.CATALOG_RULES[edition]["partner_years"]
    assert brk or abs(yrs - limit) >= 0.3, "boundary case would be ambiguous"
    ok = yrs < limit and not brk
    ans = catalog_for(ps, py) if ok else edition
    brk_s = ("was not enrolled at the partner college for two consecutive fall or spring semesters"
             if brk else "was continuously enrolled at the partner college")
    q = (f"Applying the Catalog Rights policy in the {disp(edition)} catalog: a student first enrolled at a partner community college in "
         f"{ps} {py}, {brk_s}, and first enrolled at the university in {us} {uy}. Which catalog year applies to the student?")
    yr = edition[2:4]
    critical.append({"q": q, "answer": ans, "gold": [f"CR{yr}-01", f"CR{yr}-03"],
                     "dis": [f"CR{y[2:4]}-03" for y in P.YEARS if y != edition], "scenario": "partner",
                     "params": {"partner_first": f"{ps} {py}", "university_first": f"{us} {uy}", "partner_break": brk,
                                "years_between": yrs, "edition": edition}})

# C. election (4) and D. first term (6)
for first, elect, ed in [(("Fall", 2023), "2025-26", "2025-26"), (("Fall", 2024), "2025-26", "2025-26"),
                         (("Fall", 2024), "2023-24", "2025-26"), (("Spring", 2025), "2023-24", "2025-26")]:
    assigned = catalog_for(*first)
    ans = elect if elect > assigned else assigned
    q = (f"Applying the Catalog Rights policy in the {disp(ed)} catalog: a student first enrolled at the university in {fmt(first)}, has "
         f"been continuously enrolled, and asked the degree audit office in Fall 2025 to follow the {disp(elect)} catalog. Which catalog year "
         f"applies to the student?")
    yr = ed[2:4]
    critical.append({"q": q, "answer": ans, "gold": [f"CR{yr}-01"], "dis": [f"CR{y[2:4]}-01" for y in P.YEARS if y != ed],
                     "scenario": "election", "params": {"first": fmt(first), "requested": elect, "edition": ed}})
for first in [("Spring", 2024), ("Summer", 2024), ("Fall", 2024), ("Spring", 2025), ("Summer", 2025), ("Spring", 2026)]:
    ans = catalog_for(*first)
    ed = "2025-26"
    q = (f"Applying the Catalog Rights policy in the {disp(ed)} catalog: a student's first term of enrollment at the university was "
         f"{fmt(first)}, and the student has been continuously enrolled since. Which catalog year applies to the student?")
    critical.append({"q": q, "answer": ans, "gold": ["CR25-01"], "dis": ["CR23-01", "CR24-01"],
                     "scenario": "first_term", "params": {"first": fmt(first), "edition": ed}})
assert len(critical) == 40, len(critical)

# ------------------------------------------------------------ evaluation set
# 260 non-critical items: phrasing 1 of each fact, dropping 12 major-credit facts deterministically.
drop = [f for f in facts if f["doc_id"] in PROGDOCS and f["idx"] == 1]
rng.shuffle(drop)
drop_ids = {(f["passage_id"], f["idx"]) for f in drop[:len(facts) - 260]}
items = []
for f in facts:
    if (f["passage_id"], f["idx"]) in drop_ids:
        continue
    q = f["eval_q"][0]
    if f["doc_id"] in PROGDOCS:
        cat = "program_requirements"
        code = f["doc_id"][:-2]
        dis = [f"{code}{y[2:4]}-01" for y in P.YEARS if f"{code}{y[2:4]}-01" != f["passage_id"]]
    elif f["doc_id"] in CATDOCS:
        cat = "catalog_editions"
        dis = [f"{f['doc_id'][:2]}{y[2:4]}-{f['passage_id'][-2:]}" for y in P.YEARS if f"{f['doc_id'][:2]}{y[2:4]}" != f["doc_id"]]
    else:
        cat = "policy"
        dis = distractors([f["passage_id"]], 2, q)
    items.append({"category": cat, "critical": False, "question": q, "gold_passages": [f["passage_id"]],
                  "distractor_passages": dis, **ans_record(f)})
assert len(items) == 260, len(items)
for c in critical:
    items.append({"category": "catalog_year", "critical": True, "question": c["q"], "gold_passages": c["gold"],
                  "distractor_passages": c["dis"], "answer_type": "catalog", "answer": c["answer"],
                  "answer_display": disp(c["answer"]), "scenario": c["scenario"], "scenario_params": c["params"]})
rng.shuffle(items)
for i, it in enumerate(items, 1):
    it["id"] = f"E{i:03d}"
    ctx = it["gold_passages"] + it["distractor_passages"]
    random.Random(SEED + i).shuffle(ctx)
    it["context_passages"] = ctx

# repeatability subset: 5 critical + 15 others, fixed
crit_ids = [it["id"] for it in items if it["critical"]]
oth_ids = [it["id"] for it in items if not it["critical"]]
r2 = random.Random(SEED + 7)
rep = sorted(r2.sample(crit_ids, 5) + r2.sample(oth_ids, 15))

# -------------------------------------------------------- retrieval questions
rq = []
for f in facts:
    if f["ret_q"]:
        rel = [f["passage_id"]] + P.FAQ_LINKS.get(f["passage_id"], [])
        rq.append({"question": f["ret_q"], "relevant": rel, "source_passage": f["passage_id"]})
for name, code, yrs in P.PROGRAMS:
    short = name.split(",")[0]
    for y in P.YEARS:
        pid = f"{code}{y[2:4]}-01"
        rq.append({"question": f"How many credits in the major for {short} under the {disp(y)} catalog?",
                   "relevant": [pid], "source_passage": pid})
assert len(rq) == 200, len(rq)
random.Random(SEED + 3).shuffle(rq)
for i, r in enumerate(rq, 1):
    r["id"] = f"R{i:03d}"

w(os.path.join(OUT, "corpus", "passages.jsonl"), passages)
w(os.path.join(OUT, "eval", "catalog_eval.jsonl"), items)
w(os.path.join(OUT, "retrieval", "questions.jsonl"), rq)
with open(os.path.join(OUT, "eval", "repeatability_subset.txt"), "w", newline="\n") as fh:
    fh.write("\n".join(rep) + "\n")

print(f"passages {len(passages)} from {len(P.DOCS)} documents")
print("eval items", len(items), Counter(it["category"] for it in items))
print("critical answers", Counter(it["answer"] for it in items if it["critical"]))
print("critical scenarios", Counter(it["scenario"] for it in items if it["critical"]))
print("retrieval questions", len(rq), "with 2+ relevant:", sum(len(r["relevant"]) > 1 for r in rq))
