#!/usr/bin/env bash
# Build, sign, and check the model package for the Chapter 18 laboratory.
#
# Run from the package root on a machine with network access, once per term.
# This script was written against the tools' documented command lines but could
# not be executed where the package was authored (no network). Run it step by
# step the first time, and confirm each tool's flags with --help for the
# versions you pin. Record those versions in lab_config.json.
#
# Requirements: git, Python 3.10+, cmake and a C compiler (to build llama.cpp),
# openssl, huggingface_hub (hf CLI), model-signing (pip install model-signing==<pinned>).
set -euo pipefail

# ---- 1. Choose and pin the model ---------------------------------------------------------
# Pick an instruction-tuned model of roughly 1-3B parameters with a license that allows
# redistribution of derivatives to students (Apache-2.0 or MIT is simplest; check the
# license text, and record its SPDX identifier). Pin an exact commit, not a branch.
MODEL_REPO="${MODEL_REPO:?set MODEL_REPO, e.g. an org/model-name on the Hugging Face Hub}"
MODEL_REV="${MODEL_REV:?set MODEL_REV to the exact commit hash}"
LLAMA_CPP_TAG="${LLAMA_CPP_TAG:?set LLAMA_CPP_TAG to a llama.cpp release tag, e.g. bNNNN}"

mkdir -p work model/gguf instructor_only keys
hf download "$MODEL_REPO" --revision "$MODEL_REV" --local-dir work/hf

# ---- 2. Build the runtime and convert ----------------------------------------------------
[ -d work/llama.cpp ] || git clone --depth 1 --branch "$LLAMA_CPP_TAG" https://github.com/ggml-org/llama.cpp work/llama.cpp
( cd work/llama.cpp && cmake -B build && cmake --build build --config Release -j )
pip install -r work/llama.cpp/requirements/requirements-convert_hf_to_gguf.txt
python3 work/llama.cpp/convert_hf_to_gguf.py work/hf --outtype f16 --outfile model/gguf/model-f16.gguf
work/llama.cpp/build/bin/llama-quantize model/gguf/model-f16.gguf model/gguf/model-q4_k_m.gguf Q4_K_M

# ---- 3. Copy tokenizer, configuration, and license files for the integrity tasks ---------
for f in tokenizer.json tokenizer_config.json special_tokens_map.json config.json generation_config.json LICENSE; do
  [ -f "work/hf/$f" ] && cp "work/hf/$f" model/
done
# Optional: also ship the source safetensors (model/safetensors/) if disk space allows.

# ---- 4. Record provenance -----------------------------------------------------------------
python3 - "$MODEL_REPO" "$MODEL_REV" "$LLAMA_CPP_TAG" <<'PY'
import hashlib, json, sys, subprocess, time
repo, rev, tag = sys.argv[1:4]
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
prov = {
  "model_name": repo, "source_url": f"https://huggingface.co/{repo}", "source_revision": rev,
  "license": "FILL SPDX identifier", "architecture": "FILL",
  "converted_by": "FILL instructor name", "converted_on": time.strftime("%Y-%m-%d"),
  "conversion_tool": f"llama.cpp {tag} convert_hf_to_gguf.py --outtype f16",
  "quantization_tool": f"llama.cpp {tag} llama-quantize", "quantization_method": "Q4_K_M",
  "chat_template_source": "embedded in GGUF by the converter from the source tokenizer_config.json",
  "sha256_f16_gguf": sha("model/gguf/model-f16.gguf"), "sha256_q4_gguf": sha("model/gguf/model-q4_k_m.gguf"),
}
json.dump(prov, open("model/PROVENANCE.json", "w"), indent=2)
print(json.dumps(prov, indent=2))
PY
echo "Edit model/PROVENANCE.json to fill the license and architecture before signing."
read -r -p "Press Enter when PROVENANCE.json is complete... "

# ---- 5. Inventory, keys, signature --------------------------------------------------------
python3 tools/hash_inventory.py create model/ --out model/RELEASE_INVENTORY.json
openssl ecparam -name secp256r1 -genkey -noout -out instructor_only/signing_priv.pem
openssl ec -in instructor_only/signing_priv.pem -pubout -out keys/instructor_signing_pub.pem
model_signing sign key --signature model.sig --private_key instructor_only/signing_priv.pem model/
model_signing verify key --signature model.sig --public_key keys/instructor_signing_pub.pem model/
python3 tools/key_fingerprint.py keys/instructor_signing_pub.pem | tee instructor_only/fingerprint.txt
echo "Put this fingerprint in lab_config.json (expected_signer_public_key_sha256) and publish it on the course site."

# ---- 6. Tampered copy (one changed tokenizer file) ----------------------------------------
python3 instructor/make_tampered_copy.py model/ model_tampered/ --key-out instructor_only/tamper_key.json
if model_signing verify key --signature model.sig --public_key keys/instructor_signing_pub.pem model_tampered/; then
  echo "ERROR: tampered copy verified; do not distribute" >&2; exit 1
else
  echo "Tampered copy correctly fails verification."
fi

# ---- 7. Reference run times ----------------------------------------------------------------
echo "Now run tests/reference_run.sh on the reference hardware and record the times in lab_config.json."
echo "Distribute the package WITHOUT instructor_only/ and work/."
