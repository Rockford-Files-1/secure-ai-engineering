#!/usr/bin/env python3
"""Create a stand-in model directory with the same layout as the real package, for pipeline tests.

The GGUF files are random bytes, not models. Nothing here can be loaded by a runtime.

Usage: python3 tests/make_fake_model.py <dir>
"""
import json
import os
import random
import sys

d = sys.argv[1]
os.makedirs(os.path.join(d, "gguf"), exist_ok=True)
rng = random.Random(18)
for name, size in (("gguf/model-f16.gguf", 3_000_000), ("gguf/model-q4_k_m.gguf", 900_000)):
    with open(os.path.join(d, name), "wb") as f:
        f.write(b"GGUF" + bytes(rng.getrandbits(8) for _ in range(size)))
tpl = ("{% for m in messages %}{% if loop.first and m['role'] != 'system' %}<|system|>You are a helpful assistant.<|end|>{% endif %}"
       "<|{{ m['role'] }}|>{{ m['content'] }}<|end|>{% endfor %}<|assistant|>")
json.dump({"chat_template": tpl, "bos_token": "<s>", "eos_token": "<|end|>"}, open(os.path.join(d, "tokenizer_config.json"), "w"), indent=2)
json.dump({"version": "1.0", "model": {"type": "BPE", "vocab": {f"tok{i}": i for i in range(500)}}}, open(os.path.join(d, "tokenizer.json"), "w"))
json.dump({"architectures": ["StandInForCausalLM"], "hidden_size": 64}, open(os.path.join(d, "config.json"), "w"), indent=2)
open(os.path.join(d, "LICENSE"), "w").write("Stand-in license text for pipeline tests.\n")
json.dump({"model_name": "stand-in/test-model", "source_url": "https://example.invalid/stand-in", "source_revision": "0" * 40,
           "license": "Apache-2.0", "architecture": "stand-in", "quantization_tool": "none (random bytes)", "quantization_method": "Q4_K_M"},
          open(os.path.join(d, "PROVENANCE.json"), "w"), indent=2)
print(f"stand-in model directory written to {d}")
