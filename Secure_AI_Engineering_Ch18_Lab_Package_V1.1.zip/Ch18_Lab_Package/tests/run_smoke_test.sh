#!/usr/bin/env bash
# End-to-end pipeline test with a mock model and the offline hashing embedder.
# Needs only Python 3.9+, numpy, and openssl. Takes about a minute.
# Every number it prints is a pipeline check, not a lab result.
#
# Usage: bash tests/run_smoke_test.sh [workdir]
set -euo pipefail
cd "$(dirname "$0")/.."
W="${1:-$(mktemp -d)}"
mkdir -p "$W"
export LAB_API_KEY="smoke-test-key"
PY=python3
pids=()
cleanup() { for p in "${pids[@]:-}"; do kill "$p" 2>/dev/null || true; done; }
trap cleanup EXIT
step() { printf '\n== %s\n' "$*"; }
wait_port() { for _ in $(seq 50); do $PY -c "import socket,sys;s=socket.socket();s.settimeout(.2);sys.exit(s.connect_ex(('127.0.0.1',$1)))" && return 0; sleep 0.2; done; echo "port $1 did not open"; exit 1; }

step "1. statistics reproduce the book's intervals"
$PY tools/labstats.py --selftest

step "2. datasets regenerate byte for byte"
$PY instructor/data_build/build_data.py "$W/data_regen" >/dev/null
for f in corpus/passages.jsonl eval/catalog_eval.jsonl retrieval/questions.jsonl eval/repeatability_subset.txt; do
  cmp -s "data/$f" "$W/data_regen/$f" && echo "identical: $f" || { echo "DIFFERS: $f"; exit 1; }
done

step "3. integrity: inventory, key fingerprint, tampered copy, load gate"
$PY tests/make_fake_model.py "$W/model"
$PY tools/hash_inventory.py create "$W/model" --out "$W/model/RELEASE_INVENTORY.json"
openssl ecparam -name secp256r1 -genkey -noout -out "$W/priv.pem" 2>/dev/null
openssl ec -in "$W/priv.pem" -pubout -out "$W/pub.pem" 2>/dev/null
FP=$($PY tools/key_fingerprint.py "$W/pub.pem")
$PY tools/key_fingerprint.py "$W/pub.pem" --expect "$FP" | tail -1
$PY instructor/make_tampered_copy.py "$W/model" "$W/model_tampered" --key-out "$W/tamper_key.json" | head -3
if $PY tools/hash_inventory.py compare "$W/model/RELEASE_INVENTORY.json" "$W/model_tampered"; then echo "ERROR: tamper not detected"; exit 1; fi
$PY tools/load_gate.py --config q4 --model-dir "$W/model" --public-key "$W/pub.pem" --record "$W/gate_ok.json" --pipeline-test
if $PY tools/load_gate.py --config q4 --model-dir "$W/model_tampered" --public-key "$W/pub.pem" --record "$W/gate_bad.json" --pipeline-test; then
  echo "ERROR: load gate allowed the tampered copy"; exit 1; else echo "load gate refused the tampered copy (expected)"; fi

step "4. AI-BOM from the deployed files"
$PY tools/generate_aibom.py --model-dir "$W/model" --config q4 --runtime-name mock --runtime-version test --out "$W/aibom.cdx.json"
$PY -c "import json,sys;b=json.load(open(sys.argv[1]));print(b['bomFormat'],b['specVersion'],len(b['components']),'components')" "$W/aibom.cdx.json"

step "5. endpoint check against a loopback-bound mock"
$PY tests/mock_llm_server.py --profile full --port 18080 & pids+=($!)
wait_port 18080
$PY tools/check_endpoint.py --port 18080 --record "$W/endpoint.json" | $PY -c "import json,sys;d=json.load(sys.stdin);[print(' ',t['method'],'->',t['result']) for t in d['tests']];print(' verdict:',d['verdict'])"
kill "${pids[-1]}"; unset 'pids[-1]'

step "6. quality comparison with the mock model"
$PY tests/mock_llm_server.py --profile full --port 18080 & pids+=($!); wait_port 18080
$PY tools/run_eval.py --label full --endpoint http://127.0.0.1:18080/v1/chat/completions --out "$W/eval_full.jsonl" >/dev/null 2>&1
kill "${pids[-1]}"; unset 'pids[-1]'
$PY tests/mock_llm_server.py --profile q4 --port 18080 --jitter 0.05 & pids+=($!); wait_port 18080
$PY tools/run_eval.py --label q4 --endpoint http://127.0.0.1:18080/v1/chat/completions --out "$W/eval_q4.jsonl" >/dev/null 2>&1
for i in 1 2 3; do
  $PY tools/run_eval.py --label q4 --subset data/eval/repeatability_subset.txt --endpoint http://127.0.0.1:18080/v1/chat/completions --out "$W/rep_q4_$i.jsonl" >/dev/null 2>&1
done
kill "${pids[-1]}"; unset 'pids[-1]'
$PY tools/score_eval.py "$W/eval_full.jsonl" --ledger "$W/ledger_full.csv"
$PY tools/score_eval.py "$W/eval_q4.jsonl" --ledger "$W/ledger_q4.csv"
$PY tools/compare_eval.py "$W/ledger_full.csv" "$W/ledger_q4.csv" --out "$W/quality.md" | sed -n '5,6p'
$PY tools/repeatability.py "$W/rep_q4_1.jsonl" "$W/rep_q4_2.jsonl" "$W/rep_q4_3.jsonl" --scored-run "$W/eval_q4.jsonl" --out "$W/repeat.md"

step "7. retrieval comparison with the hashing embedder (pipeline test only)"
$PY tools/retrieval/build_index.py --embedder hashing --out "$W/index" | tail -1
$PY - "$W" <<'PY'
import json, sys, re
p = "lab_config.json"; c = json.load(open(p))
c["retrieval"]["service_port"], c["retrieval"]["pir_ports"] = 18765, [18766, 18767]
json.dump(c, open(sys.argv[1] + "/lab_config.test.json", "w"), indent=2)
PY
cp lab_config.json "$W/lab_config.orig.json"; cp "$W/lab_config.test.json" lab_config.json
restore() { cp "$W/lab_config.orig.json" lab_config.json; cleanup; }
trap restore EXIT
$PY tools/retrieval/service.py --index "$W/index" --log "$W/service_log.jsonl" & pids+=($!)
$PY tools/retrieval/service.py --index "$W/index" --role pir --port 18766 --log "$W/pir1_log.jsonl" & pids+=($!)
$PY tools/retrieval/service.py --index "$W/index" --role pir --port 18767 --log "$W/pir2_log.jsonl" & pids+=($!)
wait_port 18765; wait_port 18766; wait_port 18767
for d in a b c pir; do
  $PY tools/retrieval/client.py --design $d --embedder hashing --index-meta "$W/index/meta.json" --out "$W/retrieval_$d" --reps 3
done
$PY tools/retrieval/compare_retrieval.py --prefix "$W/retrieval" --designs a b c pir --service-log "$W/service_log.jsonl" \
   --pir-logs "$W/pir1_log.jsonl" "$W/pir2_log.jsonl" --out "$W/retrieval.md" | sed -n '1,12p'

step "SMOKE TEST PASSED. Outputs in $W"
