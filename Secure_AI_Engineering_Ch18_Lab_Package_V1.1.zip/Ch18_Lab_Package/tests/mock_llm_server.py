#!/usr/bin/env python3
"""Mock OpenAI-compatible model server, for testing the lab pipeline without a model.

It is NOT a model. It looks the question up in the answer key and returns the
right or a wrong answer according to a deterministic error profile, so the
scoring, comparison, and repeatability tools can be exercised end to end.
Never report its results.

Usage:
  python3 tests/mock_llm_server.py --profile full --port 8080 [--api-key KEY] [--host 127.0.0.1] [--jitter 0.05]
"""
import argparse
import hashlib
import json
import os
import random
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
import labcommon as L

KEY = {it["question"]: it for it in L.read_jsonl(L.path("data", "eval", "catalog_eval.jsonl"))}


def u(*parts):
    return int(hashlib.sha256("|".join(parts).encode()).hexdigest()[:8], 16) / 0xFFFFFFFF


def wrong(it):
    t, a = it["answer_type"], it["answer"]
    if t == "num":
        return str(a + (1 if isinstance(a, int) else 0.25))
    if t == "yesno":
        return "no" if a == "yes" else "yes"
    if t == "catalog":
        return {"2023-24": "2024-25", "2024-25": "2025-26", "2025-26": "2023-24"}[a]
    if t == "code":
        return a[:-1] + str((int(a[-1]) + 1) % 10)
    return "the Office of the Provost"


def right(it):
    t = it["answer_type"]
    if t == "num":
        return str(it["answer"])
    if t == "catalog":
        return it["answer"]
    return it["answer_display"]


def respond(it, profile, jitter_rng, jitter):
    crit = it["critical"]
    base_err = 0.20 if crit else 0.11
    ok_full = u(it["id"], "full") > base_err
    if profile == "full":
        ok = ok_full
    else:   # 4-bit: a few regressions, fewer improvements, more in the critical category
        h = u(it["id"], "q4")
        ok = (h > (0.10 if crit else 0.02)) if ok_full else (h < 0.15)
    if jitter and jitter_rng.random() < jitter:
        ok = not ok
    return right(it) if ok else wrong(it)


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n))
        if self.server.api_key and self.headers.get("Authorization") != f"Bearer {self.server.api_key}":
            data = json.dumps({"error": "unauthorized"}).encode()
            self.send_response(401)
        else:
            user = body["messages"][-1]["content"]
            q = user.split("Question: ", 1)[1].split("\nAnswer format:", 1)[0]
            it = KEY.get(q)
            text = respond(it, self.server.profile, self.server.rng, self.server.jitter) if it else "I don't know"
            time.sleep(0.002)
            data = json.dumps({"choices": [{"message": {"role": "assistant", "content": text}}],
                               "usage": {"prompt_tokens": len(user) // 4, "completion_tokens": 3}}).encode()
            self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", choices=["full", "q4"], required=True)
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--api-key", default=os.environ.get("LAB_API_KEY", ""))
    ap.add_argument("--jitter", type=float, default=0.0, help="probability of flipping an answer, to simulate run-to-run variation")
    a = ap.parse_args()
    srv = ThreadingHTTPServer((a.host, a.port), H)
    srv.profile, srv.api_key, srv.jitter, srv.rng = a.profile, a.api_key, a.jitter, random.Random()
    print(f"MOCK model ({a.profile}) on {a.host}:{a.port}", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
