#!/usr/bin/env bash
# Instructor reference run on real hardware: the end-to-end trial the package needs
# before teaching use. Produces the reference run times for lab_config.json and a
# complete set of expected outputs to compare student submissions against.
#
# Prerequisites: the signed model package (instructor/build_model_package.sh),
# llama-server on PATH, model_signing installed, sentence-transformers installed
# with the embedding model downloaded, and lab_config.json fully filled in.
#
# Usage: LAB_API_KEY=$(openssl rand -hex 16) bash tests/reference_run.sh results_reference
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${1:-results_reference}"
mkdir -p "$OUT"
: "${LAB_API_KEY:?set LAB_API_KEY}"
PORT=$(python3 -c "import json;print(json.load(open('lab_config.json'))['runtime']['port'])")
pid=""
stop() { [ -n "$pid" ] && kill "$pid" 2>/dev/null || true; pid=""; }
trap stop EXIT
wait_ready() {
  for _ in $(seq 300); do
    curl -sf -H "Authorization: Bearer $LAB_API_KEY" "http://127.0.0.1:$PORT/health" >/dev/null 2>&1 && return 0; sleep 1
  done; echo "runtime did not become ready"; exit 1
}
t() { date +%s; }

echo "== integrity"
python3 tools/key_fingerprint.py keys/instructor_signing_pub.pem \
  --expect "$(python3 -c "import json;print(json.load(open('lab_config.json'))['model']['expected_signer_public_key_sha256'])")"
python3 tools/hash_inventory.py create model/ --out "$OUT/inventory_model.json"
if [ -d model_tampered ]; then
  python3 tools/load_gate.py --config q4 --model-dir model_tampered/ --record "$OUT/load_gate_tampered.json" && \
    { echo "ERROR: tampered copy passed the gate"; exit 1; } || echo "tampered copy refused (expected)"
fi

for cfg in full q4; do
  echo "== $cfg"
  python3 tools/load_gate.py --config "$cfg" --record "$OUT/load_gate_$cfg.json" --exec > "$OUT/runtime_$cfg.log" 2>&1 &
  pid=$!
  wait_ready
  python3 tools/check_endpoint.py --port "$PORT" --record "$OUT/endpoint_$cfg.json" >/dev/null
  s=$(t); python3 tools/run_eval.py --label "$cfg" --out "$OUT/eval_$cfg.jsonl"; echo "$cfg 300 questions: $(( $(t) - s )) s" | tee -a "$OUT/timings.txt"
  for i in 1 2 3; do python3 tools/run_eval.py --label "$cfg" --subset data/eval/repeatability_subset.txt --out "$OUT/rep_${cfg}_$i.jsonl" >/dev/null; done
  python3 tools/score_eval.py "$OUT/eval_$cfg.jsonl" --ledger "$OUT/ledger_$cfg.csv"
  python3 tools/repeatability.py "$OUT"/rep_${cfg}_{1,2,3}.jsonl --scored-run "$OUT/eval_$cfg.jsonl" --out "$OUT/repeatability_$cfg.md"
  stop
done
python3 tools/compare_eval.py "$OUT/ledger_full.csv" "$OUT/ledger_q4.csv" --out "$OUT/quality_comparison.md"

echo "== retrieval"
s=$(t)
python3 tools/retrieval/build_index.py --embedder st --out "$OUT/index"
python3 tools/retrieval/service.py --index "$OUT/index" --log "$OUT/service_log.jsonl" & spid=$!
python3 tools/retrieval/service.py --index "$OUT/index" --role pir --port 8766 --log "$OUT/pir1_log.jsonl" & p1=$!
python3 tools/retrieval/service.py --index "$OUT/index" --role pir --port 8767 --log "$OUT/pir2_log.jsonl" & p2=$!
sleep 3
for d in a b c pir; do
  python3 tools/retrieval/client.py --design "$d" --embedder st --index-meta "$OUT/index/meta.json" --out "$OUT/retrieval_$d"
done
kill $spid $p1 $p2
python3 tools/retrieval/compare_retrieval.py --prefix "$OUT/retrieval" --designs a b c pir --service-log "$OUT/service_log.jsonl" \
  --pir-logs "$OUT/pir1_log.jsonl" "$OUT/pir2_log.jsonl" --out "$OUT/retrieval_comparison.md"
echo "retrieval, all designs: $(( $(t) - s )) s" | tee -a "$OUT/timings.txt"

python3 tools/generate_aibom.py --config q4 --runtime-name llama.cpp \
  --runtime-version "$(llama-server --version 2>&1 | head -1)" --runtime-binary "$(command -v llama-server)" \
  --embedder-meta "$OUT/index/meta.json" --out "$OUT/aibom_q4.cdx.json"
echo "Reference run complete. Copy the times in $OUT/timings.txt into lab_config.json."
