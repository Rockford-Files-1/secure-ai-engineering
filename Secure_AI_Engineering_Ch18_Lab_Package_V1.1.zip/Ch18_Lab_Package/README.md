# Chapter 18 Laboratory Package

*Secure AI Engineering*, Chapter 18: Local Deployment, Integrity Verification, and Private Retrieval. Package version 1.1 (November 13, 2026: book appendix names; Chapter 13 criterion statuses in the gate tools).

Alder Valley University is fictional. Every policy, program, and number in this package is invented for teaching.

## Status

The tools and datasets are complete and pass `tests/run_smoke_test.sh`, which runs every step with a mock model server and an offline stand-in embedder. The package is **not ready for students** until the instructor has completed three steps:

- **Build the signed model package** with `instructor/build_model_package.sh`.
- **Fill every `FILL` value** in `lab_config.json`.
- **Complete the end-to-end trial** on lab hardware with `tests/reference_run.sh`.

See the Instructor Guide.

## Contents

| Path | What it is |
|---|---|
| `lab_config.json` | Predeclared settings: prompt, generation, scoring, gate method and margins, retrieval parameters |
| `data/corpus/passages.jsonl` | 95 policy passages from 64 fictional documents |
| `data/eval/catalog_eval.jsonl` | 300-question catalog evaluation with answer key; 40 catalog-year questions form the critical category |
| `data/eval/repeatability_subset.txt` | The 20 questions rerun three times |
| `data/retrieval/questions.jsonl` | 200 retrieval questions with relevance labels |
| `tools/load_gate.py` | Load-time verification: key fingerprint, signature, inventory, artifact, loopback, auth |
| `tools/hash_inventory.py`, `tools/key_fingerprint.py` | Hash inventories and tamper detection; signing-key fingerprint |
| `tools/generate_aibom.py` | CycloneDX AI-BOM from the deployed files |
| `tools/check_endpoint.py` | Listening sockets and reachability from a separate namespace or host |
| `tools/run_eval.py`, `score_eval.py`, `compare_eval.py`, `repeatability.py` | Quality comparison with Wilson and Newcombe method-10 intervals |
| `tools/labstats.py` | Statistics; `--selftest` reproduces the chapter's intervals |
| `tools/retrieval/` | Index builder, logging service, clients for designs (a), (b), (c), and two-server PIR |
| `tests/` | Smoke test, mock model, stand-in model directory, reference run |
| `instructor/` | Model package build, tampered-copy tool, dataset generator |

## Quick check (no model needed)

```
bash tests/run_smoke_test.sh
```

Requires Python 3.9+, numpy, and openssl. The numbers it prints test the pipeline only and must not be reported.

## Requirements for the real lab

- **Python and libraries.** Python 3.9+ with numpy, and sentence-transformers with the embedding model named in `lab_config.json`.
- **Runtime.** llama.cpp `llama-server` (or another runtime with an OpenAI-compatible API, documented in the student's report).
- **Signing.** OpenSSF `model-signing` at the version pinned in `lab_config.json`.
- **Separate-namespace test.** Linux with `ip` and root, Docker with a locally available image that has python3, or a second machine or VM.
