#!/usr/bin/env python3
"""Compare two scored ledgers with the package's predeclared method and margins.

Usage:
  python3 tools/compare_eval.py results/ledger_full.csv results/ledger_q4.csv --out results/quality_comparison.md

Reports, overall and for the catalog-year (critical) category:
  accuracy with 95% Wilson intervals for each configuration,
  the paired table (regressions and improvements),
  the paired difference with its Newcombe method-10 interval,
  the exact McNemar p-value (a test of difference, not a preservation claim),
  and the gate decision against the margin fixed in lab_config.json.
"""
import argparse
import csv
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import labcommon as L
import labstats as S


def pts(x):
    v = round(100 * x, 1)
    return f"{v + 0.0:+.1f}"


def load(p):
    with open(p, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("reference_ledger")
    ap.add_argument("candidate_ledger")
    ap.add_argument("--ref-name", default="full precision")
    ap.add_argument("--cand-name", default="4-bit")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    cfg = L.config()["gate"]
    if cfg["method"] != "newcombe10":
        sys.exit("lab_config.json names a method this tool does not implement")
    R, C = load(a.reference_ledger), load(a.candidate_ledger)
    cat = {r["id"]: r for r in R}
    groups = {"overall": lambda r: True, "catalog_year": lambda r: r["critical"] == "1"}
    out = {"method": "Newcombe method 10, 95%", "margins_points": cfg["margin_points"], "groups": {}}
    lines = [f"# Quality comparison: {a.cand_name} vs {a.ref_name}", "",
             f"Method: Newcombe method 10 paired interval, 95%, predeclared in lab_config.json. Difference = {a.cand_name} minus {a.ref_name}.", "",
             "| Group | n | " + a.ref_name + " correct [Wilson] | " + a.cand_name + " correct [Wilson] | Regressions / improvements | Paired difference [interval], points | Margin | Decision | Exact McNemar p |",
             "|---|---|---|---|---|---|---|---|---|"]
    for g, sel in groups.items():
        ref = {r["id"]: int(r["correct"]) for r in R if sel(r)}
        cand = {r["id"]: int(r["correct"]) for r in C if sel(cat.get(r["id"], r))}
        A, B, Cc, D = S.paired_table(ref, cand)
        n = A + B + Cc + D
        k1, k2 = A + B, A + Cc
        w1, w2 = S.wilson(k1, n), S.wilson(k2, n)
        diff, lo, hi = S.newcombe10(A, B, Cc, D)
        margin = cfg["margin_points"].get(g)
        decision = S.margin_decision(lo, margin / 100, hi) if margin is not None else "descriptive only"
        p = S.mcnemar_exact(B, Cc)
        out["groups"][g] = {"n": n, "reference_correct": k1, "candidate_correct": k2, "reference_wilson": w1, "candidate_wilson": w2,
                            "table": {"a_both": A, "b_regressions": B, "c_improvements": Cc, "d_neither": D},
                            "difference": diff, "interval": [lo, hi], "margin_points": margin, "decision": decision, "mcnemar_p": p}
        lines.append(f"| {g} | {n} | {k1} ({S.pct(k1/n)}%) [{S.pct(w1[0])}, {S.pct(w1[1])}] | {k2} ({S.pct(k2/n)}%) [{S.pct(w2[0])}, {S.pct(w2[1])}] | "
                     f"{B} / {Cc} | {pts(diff)} [{pts(lo)}, {pts(hi)}] | {margin} | {decision} | {p:.3g} |")
    # descriptive breakdown for the other categories
    lines += ["", "Descriptive breakdown (no margin is predeclared for these categories):", "", "| Category | n | Reference | Candidate |", "|---|---|---|---|"]
    for c in sorted({r["category"] for r in R}):
        ids = [r["id"] for r in R if r["category"] == c]
        rr = sum(int(cat[i]["correct"]) for i in ids)
        cc = sum(int(r["correct"]) for r in C if r["id"] in ids)
        lines.append(f"| {c} | {len(ids)} | {rr} | {cc} |")
    reg = [r["id"] for r in R if r["correct"] == "1" and next(x for x in C if x["id"] == r["id"])["correct"] == "0"]
    imp = [r["id"] for r in R if r["correct"] == "0" and next(x for x in C if x["id"] == r["id"])["correct"] == "1"]
    lines += ["", f"Regressions (reference correct, candidate wrong): {', '.join(reg) or 'none'}",
              f"Improvements (candidate correct, reference wrong): {', '.join(imp) or 'none'}",
              "", "The McNemar test asks whether the configurations differ. The gate asks a different question: whether the interval shows the decline is smaller than the margin. A non-significant test does not establish preservation."]
    out["regressions"], out["improvements"] = reg, imp
    with open(a.out, "w") as f:
        f.write("\n".join(lines) + "\n")
    with open(os.path.splitext(a.out)[0] + ".json", "w") as f:
        json.dump(out, f, indent=2)
    print("\n".join(lines))


if __name__ == "__main__":
    main()
