#!/usr/bin/env python3
"""Run the catalog evaluation against a local OpenAI-compatible endpoint.

Usage:
  python3 tools/run_eval.py --label full  --out results/eval_full.jsonl
  python3 tools/run_eval.py --label q4    --out results/eval_q4.jsonl
  python3 tools/run_eval.py --label q4 --subset data/eval/repeatability_subset.txt --out results/rep_q4_run1.jsonl

The prompt, generation settings, and endpoint come from lab_config.json and
must not be changed. The API key is read from the environment variable named in
lab_config.json (LAB_API_KEY by default). The tool refuses endpoints that are
not on the loopback interface, because the lab must never send prompts off the host.
"""
import argparse
import ipaddress
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(__file__))
import labcommon as L


def build_messages(cfg, item, P):
    g = cfg["generation"]
    blocks = [g["passage_template"].format(n=i, doc_title=P[pid]["doc_title"], heading=P[pid]["heading"], text=P[pid]["text"])
              for i, pid in enumerate(item["context_passages"], 1)]
    user = g["user_template"].format(passages="\n\n".join(blocks), question=item["question"],
                                     format=g["format_hints"][item["answer_type"]])
    return [{"role": "system", "content": g["system_prompt"]}, {"role": "user", "content": user}]


def loopback_only(url):
    host = urllib.parse.urlparse(url).hostname
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--label", required=True, help="configuration label, e.g. full or q4")
    ap.add_argument("--out", required=True)
    ap.add_argument("--subset", help="file of question ids to run (repeatability reruns)")
    ap.add_argument("--endpoint", help="override only if your runtime uses a different loopback port")
    ap.add_argument("--model-name", default="local", help="value sent in the 'model' field")
    ap.add_argument("--timeout", type=float, default=300)
    a = ap.parse_args()

    cfg = L.config()
    g = cfg["generation"]
    url = a.endpoint or g["endpoint"]
    if not loopback_only(url):
        sys.exit(f"refusing non-loopback endpoint {url}")
    key = os.environ.get(cfg["runtime"]["api_key_env"], "")
    items = L.read_jsonl(L.path("data", "eval", "catalog_eval.jsonl"))
    if a.subset:
        keep = set(open(a.subset).read().split())
        items = [it for it in items if it["id"] in keep]
    P = L.passages()

    rows = []
    t_start = time.time()
    for n, it in enumerate(items, 1):
        body = {"model": a.model_name, "messages": build_messages(cfg, it, P), "temperature": g["temperature"],
                "top_p": g["top_p"], "seed": g["seed"], "max_tokens": g["max_tokens"], "stream": False}
        req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                     headers={"Content-Type": "application/json", **({"Authorization": f"Bearer {key}"} if key else {})})
        t0 = time.perf_counter()
        try:
            with urllib.request.urlopen(req, timeout=a.timeout) as r:
                resp = json.loads(r.read())
            text = resp["choices"][0]["message"]["content"]
            usage = resp.get("usage", {})
            err = ""
        except (urllib.error.URLError, KeyError, json.JSONDecodeError, TimeoutError) as e:
            text, usage, err = "", {}, f"{type(e).__name__}: {e}"
        ms = (time.perf_counter() - t0) * 1000
        rows.append({"id": it["id"], "label": a.label, "response": text, "latency_ms": round(ms, 1),
                     "prompt_tokens": usage.get("prompt_tokens"), "completion_tokens": usage.get("completion_tokens"), "error": err})
        if err and n == 1:
            sys.exit(f"first request failed ({err}); is the runtime running on {url} with the right API key?")
        if n % 25 == 0 or n == len(items):
            print(f"{a.label}: {n}/{len(items)}  elapsed {time.time() - t_start:.0f}s", file=sys.stderr)

    L.write_jsonl(a.out, rows)
    meta = {"label": a.label, "endpoint": url, "n": len(rows), "errors": sum(1 for r in rows if r["error"]),
            "wall_seconds": round(time.time() - t_start, 1), "generation": {k: g[k] for k in ("temperature", "top_p", "seed", "max_tokens")},
            "host": L.host_record(), "started": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(t_start))}
    with open(a.out + ".meta.json", "w") as f:
        json.dump(meta, f, indent=2)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
