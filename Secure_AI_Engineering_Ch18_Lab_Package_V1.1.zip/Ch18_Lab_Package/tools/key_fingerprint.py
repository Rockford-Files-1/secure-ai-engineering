#!/usr/bin/env python3
"""Print the SHA-256 fingerprint of a PEM public key (the DER SubjectPublicKeyInfo).

Usage:
  python3 tools/key_fingerprint.py keys/instructor_signing_pub.pem
  python3 tools/key_fingerprint.py keys/instructor_signing_pub.pem --expect <fingerprint>

A key that ships beside the model proves nothing by itself: anyone who can
replace the model can replace the key. Compare the fingerprint with the value
the instructor published separately (course site, syllabus, or in class).
"""
import argparse
import base64
import hashlib
import sys


def fingerprint(pem_path):
    lines = open(pem_path).read().strip().splitlines()
    if not lines or "PUBLIC KEY" not in lines[0]:
        sys.exit(f"{pem_path} is not a PEM public key")
    der = base64.b64decode("".join(l for l in lines if not l.startswith("-----")))
    return hashlib.sha256(der).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pem")
    ap.add_argument("--expect")
    a = ap.parse_args()
    fp = fingerprint(a.pem)
    print(fp)
    if a.expect:
        if fp != a.expect.strip().lower():
            print("MISMATCH: this is not the expected signing key", file=sys.stderr)
            sys.exit(1)
        print("MATCH: expected signing key")


if __name__ == "__main__":
    main()
