#!/usr/bin/env python3
"""Generate a CycloneDX AI bill of materials from the files actually deployed.

Usage:
  python3 tools/generate_aibom.py --model-dir model/ --config q4 \
      --runtime-name llama.cpp --runtime-version "$(llama-server --version 2>&1 | head -1)" \
      --runtime-binary "$(command -v llama-server)" --out results/aibom_q4.cdx.json

The BOM lists the model artifact being served, every file in the model
directory (tokenizer files included) with SHA-256 hashes, the provenance of
the quantized conversion, the inference runtime, the Python libraries the lab
tools import, the embedding model, and the lab datasets. It is generated from
the deployed files, not typed by hand, so it can be regenerated and diffed.

Output follows CycloneDX 1.6 JSON. The fields used are unchanged in 1.7;
1.6 is emitted because more validators support it.
"""
import argparse
import hashlib
import json
import os
import sys
import time
import uuid
from importlib import metadata

sys.path.insert(0, os.path.dirname(__file__))
import hash_inventory as HI
import labcommon as L

LIBS = ["numpy", "model-signing", "sentence-transformers", "torch", "transformers"]


def sha256(p):
    return HI.sha256(p)


def lib_component(name):
    try:
        d = metadata.distribution(name)
    except metadata.PackageNotFoundError:
        return None
    lic = d.metadata.get("License-Expression") or d.metadata.get("License") or ""
    comp = {"type": "library", "bom-ref": f"pkg:pypi/{d.metadata['Name'].lower()}@{d.version}", "name": d.metadata["Name"],
            "version": d.version, "purl": f"pkg:pypi/{d.metadata['Name'].lower()}@{d.version}"}
    if lic and len(lic) < 80:
        comp["licenses"] = [{"expression": lic}] if (" " in lic or "-" in lic) else [{"license": {"name": lic}}]
    return comp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-dir", default=None)
    ap.add_argument("--config", choices=["full", "q4"], required=True)
    ap.add_argument("--runtime-name", required=True)
    ap.add_argument("--runtime-version", required=True)
    ap.add_argument("--runtime-binary", help="path to the runtime executable, hashed into the BOM")
    ap.add_argument("--embedder-meta", default=None, help="index/meta.json from build_index.py")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    cfg = L.config()
    m = cfg["model"]
    mdir = a.model_dir or L.path(m["distribution_dir"])
    prov_path = os.path.join(mdir, "PROVENANCE.json")
    prov = json.load(open(prov_path)) if os.path.exists(prov_path) else {}
    files = HI.inventory(mdir, set())
    art = (m["full_precision_file"] if a.config == "full" else m["quantized_file"]).split("/", 1)[1]
    if art not in files:
        sys.exit(f"{art} is not in {mdir}; generate the BOM from the deployed directory")

    model_ref = "model:" + art
    comps = [{
        "type": "machine-learning-model", "bom-ref": model_ref,
        "name": prov.get("model_name", m["base_model_repository"]),
        "version": prov.get("source_revision", m["base_model_revision"]),
        "description": f"{'4-bit quantized' if a.config == 'q4' else 'full-precision'} artifact served by the runtime",
        "hashes": [{"alg": "SHA-256", "content": files[art]["sha256"]}],
        "licenses": [{"license": {"id": prov.get("license", m["license"])}}],
        "externalReferences": [{"type": "distribution", "url": prov.get("source_url", "FILL")}],
        "properties": [{"name": f"lab:provenance:{k}", "value": str(v)} for k, v in sorted(prov.items()) if k not in ("model_name",)],
        "modelCard": {"modelParameters": {"task": "text-generation", "architectureFamily": prov.get("architecture", "unrecorded")}},
    }]
    file_refs = []
    for rel, info in files.items():
        ref = f"file:{rel}"
        file_refs.append(ref)
        kind = "tokenizer" if "tokenizer" in rel or rel.endswith(("vocab.json", "merges.txt", "special_tokens_map.json")) else "model-file"
        comps.append({"type": "file", "bom-ref": ref, "name": rel, "hashes": [{"alg": "SHA-256", "content": info["sha256"]}],
                      "properties": [{"name": "lab:role", "value": kind}, {"name": "lab:bytes", "value": str(info["bytes"])}]})
    rt = {"type": "application", "bom-ref": "runtime", "name": a.runtime_name, "version": a.runtime_version,
          "properties": [{"name": "lab:bind_host", "value": cfg["runtime"]["bind_host"]},
                         {"name": "lab:launch", "value": cfg["runtime"]["launch_quantized" if a.config == "q4" else "launch_full_precision"]}]}
    if a.runtime_binary and os.path.exists(a.runtime_binary):
        rt["hashes"] = [{"alg": "SHA-256", "content": sha256(a.runtime_binary)}]
    comps.append(rt)
    libs = [c for c in (lib_component(n) for n in LIBS) if c]
    comps += libs
    if a.embedder_meta:
        em = json.load(open(a.embedder_meta))
        comps.append({"type": "machine-learning-model", "bom-ref": "embedder", "name": em["embedder"], "version": em["embedder_revision"],
                      "description": "embedding model for the retrieval comparison"})
    data_refs = []
    for rel in ("data/corpus/passages.jsonl", "data/eval/catalog_eval.jsonl", "data/retrieval/questions.jsonl"):
        ref = "data:" + rel
        data_refs.append(ref)
        comps.append({"type": "data", "bom-ref": ref, "name": rel, "hashes": [{"alg": "SHA-256", "content": sha256(L.path(rel))}],
                      "data": [{"type": "dataset", "name": rel, "classification": "public, fictional"}]})
    bom = {"bomFormat": "CycloneDX", "specVersion": "1.6", "serialNumber": f"urn:uuid:{uuid.uuid4()}", "version": 1,
           "metadata": {"timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                        "tools": {"components": [{"type": "application", "name": "ch18-lab generate_aibom.py", "version": cfg["package_version"]}]},
                        "component": {"type": "application", "bom-ref": "deployment", "name": f"Chapter 18 lab deployment ({a.config})"}},
           "components": comps,
           "dependencies": [{"ref": "deployment", "dependsOn": ["runtime", model_ref] + (["embedder"] if a.embedder_meta else [])
                             + data_refs + [c["bom-ref"] for c in libs]},
                            {"ref": model_ref, "dependsOn": file_refs}]}
    with open(a.out, "w") as f:
        json.dump(bom, f, indent=2)
    print(f"wrote {a.out}: {len(comps)} components ({len(files)} model files, {len(libs)} libraries)")


if __name__ == "__main__":
    main()
