#!/usr/bin/env python3
"""The retrieval service. A separate local process plays the vendor and logs everything it receives.

Usage:
  python3 tools/retrieval/service.py --index index/ --log results/service_log.jsonl
  python3 tools/retrieval/service.py --index index/ --role pir --port 8766 --log results/pir1_log.jsonl   # optional PIR server 1
  python3 tools/retrieval/service.py --index index/ --role pir --port 8767 --log results/pir2_log.jsonl   # optional PIR server 2

Endpoints (role "service"):
  POST /search          {"embedding": [...], "k": 5}  -> top-k passages        design (a)
  GET  /centroids                                     -> centroids.npz         design (b) setup
  GET  /cluster/<j>                                   -> cluster_<j>.npz       design (b) per query
  GET  /index                                         -> full_index.npz        design (c) setup
Endpoints (role "pir"):
  POST /pir             {"bits": "<hex>"}             -> XOR of selected blocks (two-server PIR)

The service binds to 127.0.0.1 only. Each log line records what the service
could learn: the endpoint, the request body exactly as received, and bytes sent.
"""
import argparse
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pir as PIR


class State:
    pass


S = State()
LOCK = threading.Lock()


def log(entry):
    entry["ts"] = round(time.time(), 6)
    with LOCK:
        S.logf.write(json.dumps(entry) + "\n")
        S.logf.flush()


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    disable_nagle_algorithm = True     # otherwise small responses wait ~40 ms for delayed ACKs

    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/octet-stream", entry=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)
        if entry is not None:
            entry.update({"client": self.client_address[0], "status": code, "bytes_sent": len(body)})
            log(entry)

    def read_body(self):
        n = int(self.headers.get("Content-Length", 0))
        return self.rfile.read(n) if n else b""

    def do_GET(self):
        if S.role != "service":
            return self.send(404, b"", entry={"method": "GET", "path": self.path})
        if self.path == "/centroids":
            return self.send(200, S.files["centroids.npz"], entry={"method": "GET", "path": self.path})
        if self.path == "/index":
            return self.send(200, S.files["full_index.npz"], entry={"method": "GET", "path": self.path})
        if self.path.startswith("/cluster/"):
            j = self.path.rsplit("/", 1)[1]
            key = f"cluster_{int(j):02d}.npz" if j.isdigit() else None
            if key in S.files:
                return self.send(200, S.files[key], entry={"method": "GET", "path": self.path, "learned": f"query fell in cluster {int(j)}"})
        return self.send(404, b"", entry={"method": "GET", "path": self.path})

    def do_POST(self):
        raw = self.read_body()
        if S.role == "service" and self.path == "/search":
            req = json.loads(raw)
            q = np.asarray(req["embedding"], dtype=np.float32)
            k = int(req.get("k", 5))
            scores = S.X @ q
            top = np.argsort(-scores, kind="stable")[:k]
            body = json.dumps({"results": [{"id": str(S.ids[i]), "text": str(S.texts[i]), "score": float(scores[i])} for i in top]}).encode()
            return self.send(200, body, "application/json",
                             entry={"method": "POST", "path": "/search", "received_embedding": req["embedding"], "k": k,
                                    "learned": "the full query embedding (invertible to approximate text) and the results returned"})
        if S.role == "pir" and self.path == "/pir":
            req = json.loads(raw)
            ans = PIR.server_answer(S.blocks, req["bits"])
            return self.send(200, ans, entry={"method": "POST", "path": "/pir", "received_bits": req["bits"],
                                              "learned": "a uniformly random-looking bit vector; nothing about the cluster unless the two servers collude"})
        return self.send(404, b"", entry={"method": "POST", "path": self.path})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--index", required=True)
    ap.add_argument("--log", required=True)
    ap.add_argument("--role", choices=["service", "pir"], default="service")
    ap.add_argument("--port", type=int)
    a = ap.parse_args()
    sys.path.insert(0, os.path.dirname(HERE))
    import labcommon as L
    cfg = L.config()["retrieval"]
    port = a.port or cfg["service_port"]
    S.role = a.role
    S.files = {f: open(os.path.join(a.index, f), "rb").read() for f in os.listdir(a.index) if f.endswith(".npz")}
    with np.load(os.path.join(a.index, "full_index.npz"), allow_pickle=False) as z:
        S.ids, S.texts, S.X = z["ids"], z["texts"], z["embeddings"]
    if a.role == "pir":
        S.blocks = PIR.make_blocks([S.files[f] for f in sorted(S.files) if f.startswith("cluster_")])
    os.makedirs(os.path.dirname(os.path.abspath(a.log)), exist_ok=True)
    S.logf = open(a.log, "a")
    srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    print(f"{a.role} listening on 127.0.0.1:{port}, logging to {a.log}", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
