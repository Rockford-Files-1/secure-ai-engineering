"""Two-server information-theoretic PIR (Chor, Goldreich, Kushilevitz, and Sudan, 1995).

Teaching implementation for the optional advanced task. The database is a list
of n equal-length blocks (here, the cluster bundles, padded). To fetch block i,
the client draws a uniformly random n-bit vector S1, sets S2 = S1 with bit i
flipped, sends S1 to server 1 and S2 to server 2, and XORs the two answers.
Each server sees a uniformly random vector, so neither alone learns i. Privacy
fails if the two servers collude. There is no integrity protection: either
server can corrupt the result undetectably.

Cost: each query sends n bits to each server, each server reads the whole
database, and the client downloads two blocks of the padded block size.
Single-server schemes (for example SimplePIR) remove the non-collusion
assumption at higher computational cost; an instructor may substitute one.
"""
import secrets
import struct

import numpy as np


def make_blocks(bundles):
    size = max(len(b) for b in bundles) + 8
    out = np.zeros((len(bundles), size), dtype=np.uint8)
    for i, b in enumerate(bundles):
        rec = struct.pack("<Q", len(b)) + b
        out[i, :len(rec)] = np.frombuffer(rec, dtype=np.uint8)
    return out


def _bits(hexs, n):
    v = int(hexs, 16)
    return np.array([(v >> i) & 1 for i in range(n)], dtype=bool)


def server_answer(blocks, hexs):
    sel = _bits(hexs, blocks.shape[0])
    if not sel.any():
        return bytes(blocks.shape[1])
    return np.bitwise_xor.reduce(blocks[sel], axis=0).tobytes()


def client_queries(n, i):
    s1 = secrets.randbits(n)
    s2 = s1 ^ (1 << i)
    return f"{s1:x}", f"{s2:x}"


def client_decode(a1, a2):
    x = bytes(p ^ q for p, q in zip(a1, a2))
    (length,) = struct.unpack("<Q", x[:8])
    return x[8:8 + length]
