#!/usr/bin/env python3
"""Build the retrieval index with the package's predeclared parameters.

Usage:
  python3 tools/retrieval/build_index.py --embedder st      --out index/      # reported results
  python3 tools/retrieval/build_index.py --embedder hashing --out index_test/ # offline pipeline test

Writes, all as .npz files read with allow_pickle=False (no code execution on load):
  full_index.npz        ids, texts, embeddings for every passage (design c download)
  centroids.npz         k-means centroids and cluster sizes (design b setup)
  cluster_XX.npz        the passages of one cluster (design b per-query download)
  meta.json             embedder, parameters, and SHA-256 of every file written
"""
import argparse
import hashlib
import json
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
import embedder as E
import labcommon as L


def kmeans(X, k, seed, iters):
    rng = np.random.default_rng(seed)
    n = X.shape[0]
    cent = [X[rng.integers(n)]]
    for _ in range(1, k):                       # k-means++ initialization
        d = np.min(np.stack([1 - X @ c for c in cent]), axis=0).clip(min=0)
        p = d / d.sum() if d.sum() > 0 else np.full(n, 1 / n)
        cent.append(X[rng.choice(n, p=p)])
    C = np.stack(cent)
    for _ in range(iters):                      # spherical k-means on normalized vectors
        assign = np.argmax(X @ C.T, axis=1)
        for j in range(k):
            m = X[assign == j]
            if len(m):
                v = m.mean(axis=0)
                C[j] = v / (np.linalg.norm(v) or 1)
    assign = np.argmax(X @ C.T, axis=1)
    return C.astype(np.float32), assign


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--embedder", choices=["st", "hashing"], required=True)
    ap.add_argument("--model-path", help="local path to the downloaded embedding model, if not using the hub name")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    cfg = L.config()
    rc = cfg["retrieval"]
    emb = E.get(a.embedder, cfg, a.model_path)
    P = list(L.passages().values())
    ids = np.array([p["passage_id"] for p in P])
    texts = np.array([E.passage_text(p) for p in P])
    t0 = time.perf_counter()
    X = emb.encode(list(texts))
    t_embed = time.perf_counter() - t0
    C, assign = kmeans(X, rc["n_clusters"], rc["kmeans_seed"], 50)
    os.makedirs(a.out, exist_ok=True)
    np.savez(os.path.join(a.out, "full_index.npz"), ids=ids, texts=texts, embeddings=X)
    sizes = np.array([(assign == j).sum() for j in range(len(C))])
    np.savez(os.path.join(a.out, "centroids.npz"), centroids=C, sizes=sizes)
    for j in range(len(C)):
        m = assign == j
        np.savez(os.path.join(a.out, f"cluster_{j:02d}.npz"), ids=ids[m], texts=texts[m], embeddings=X[m])
    files = sorted(f for f in os.listdir(a.out) if f.endswith(".npz"))
    meta = {"embedder": emb.name, "embedder_revision": emb.revision, "dim": int(X.shape[1]), "n_passages": int(len(ids)),
            "n_clusters": int(len(C)), "cluster_sizes": sizes.tolist(), "kmeans_seed": rc["kmeans_seed"], "search": rc["search"],
            "k": rc["k"], "embed_seconds": round(t_embed, 3),
            "pipeline_test_only": a.embedder == "hashing",
            "files": {f: {"sha256": sha256(os.path.join(a.out, f)), "bytes": os.path.getsize(os.path.join(a.out, f))} for f in files}}
    with open(os.path.join(a.out, "meta.json"), "w") as f:
        json.dump(meta, f, indent=2)
    print(json.dumps({k: v for k, v in meta.items() if k != "files"}, indent=2))
    print("full index bytes:", meta["files"]["full_index.npz"]["bytes"])


if __name__ == "__main__":
    main()
