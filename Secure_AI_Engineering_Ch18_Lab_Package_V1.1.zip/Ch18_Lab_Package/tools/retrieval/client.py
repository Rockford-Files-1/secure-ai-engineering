#!/usr/bin/env python3
"""Run one retrieval design against the local service and measure it.

Usage (service must be running):
  python3 tools/retrieval/client.py --design a   --embedder st --index-meta index/meta.json --out results/retrieval_a
  python3 tools/retrieval/client.py --design b   --embedder st --index-meta index/meta.json --out results/retrieval_b
  python3 tools/retrieval/client.py --design c   --embedder st --index-meta index/meta.json --out results/retrieval_c
  python3 tools/retrieval/client.py --design pir --embedder st --index-meta index/meta.json --out results/retrieval_pir   # optional

Designs:
  a    server-side retrieval: the client sends the query embedding to /search
  b    cluster retrieval: the client fetches centroids once, picks the nearest
       cluster, downloads every passage in it, and searches locally
  c    full-index download: the client downloads the whole index once and searches locally
  pir  design b with the cluster fetched by two-server PIR (optional advanced task)

Writes <out>_ledger.csv (per-question Hit@5 and ranking) and <out>_measure.json
(setup, cold and warm latency, transfer). Embedding time is measured separately
and excluded from retrieval latency, because every design embeds on the client.
"""
import argparse
import http.client
import io
import json
import os
import socket
import subprocess
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
import embedder as E
import labcommon as L
import pir as PIR


class Conn:
    def __init__(self, port):
        self.port = port
        self.c = None
        self.sent = self.recv = 0

    def req(self, method, path, body=None):
        if self.c is None:
            self.c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=60)
            self.c.connect()
            self.c.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)   # avoid ~40 ms Nagle/delayed-ACK stalls
        data = json.dumps(body).encode() if body is not None else None
        self.c.request(method, path, body=data, headers={"Content-Type": "application/json"} if data else {})
        r = self.c.getresponse()
        out = r.read()
        if r.status != 200:
            raise RuntimeError(f"{method} {path} -> {r.status}")
        self.sent += len(data or b"") + len(path) + len(method)
        self.recv += len(out)
        return out


def npz(b):
    return np.load(io.BytesIO(b), allow_pickle=False)


def topk(X, ids, q, k):
    s = X @ q
    o = np.argsort(-s, kind="stable")[:k]
    return [str(ids[i]) for i in o]


class Design:
    def __init__(self, name, cfg, cache_dir):
        self.name, self.cfg, self.k = name, cfg, cfg["retrieval"]["k"]
        self.cache = cache_dir
        self.conn = Conn(cfg["retrieval"]["service_port"])
        if name == "pir":
            p1, p2 = cfg["retrieval"]["pir_ports"]
            self.p1, self.p2 = Conn(p1), Conn(p2)

    def setup(self):
        """One-time setup; returns bytes downloaded."""
        before = self.conn.recv
        if self.name in ("b", "pir"):
            raw = self.conn.req("GET", "/centroids")
            open(os.path.join(self.cache, "centroids.npz"), "wb").write(raw)
        elif self.name == "c":
            raw = self.conn.req("GET", "/index")
            open(os.path.join(self.cache, "full_index.npz"), "wb").write(raw)
        return self.conn.recv - before

    def load_local(self):
        """Load whatever the design keeps on the client (cold-start work)."""
        if self.name in ("b", "pir"):
            with np.load(os.path.join(self.cache, "centroids.npz"), allow_pickle=False) as z:
                self.C = z["centroids"]
        elif self.name == "c":
            with np.load(os.path.join(self.cache, "full_index.npz"), allow_pickle=False) as z:
                self.ids, self.X = z["ids"], z["embeddings"]

    def query(self, q):
        if self.name == "a":
            r = json.loads(self.conn.req("POST", "/search", {"embedding": [round(float(x), 6) for x in q], "k": self.k}))
            return [x["id"] for x in r["results"]]
        if self.name == "c":
            return topk(self.X, self.ids, q, self.k)
        j = int(np.argmax(self.C @ q))
        if self.name == "b":
            z = npz(self.conn.req("GET", f"/cluster/{j}"))
        else:
            s1, s2 = PIR.client_queries(len(self.C), j)
            a1 = self.p1.req("POST", "/pir", {"bits": s1})
            a2 = self.p2.req("POST", "/pir", {"bits": s2})
            z = npz(PIR.client_decode(a1, a2))
        return topk(z["embeddings"], z["ids"], q, self.k)

    def bytes_total(self):
        c = [self.conn] + ([self.p1, self.p2] if self.name == "pir" else [])
        return sum(x.sent for x in c), sum(x.recv for x in c)


def cold_probe(a, cfg):
    qv = np.load(a.qcache, allow_pickle=False)[a.cold_probe]
    d = Design(a.design, cfg, a.cache)
    t0 = time.perf_counter()
    d.load_local()
    d.query(qv)
    print(json.dumps({"cold_ms": (time.perf_counter() - t0) * 1000}))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--design", choices=["a", "b", "c", "pir"], required=True)
    ap.add_argument("--embedder", choices=["st", "hashing"], required=True)
    ap.add_argument("--model-path")
    ap.add_argument("--index-meta", required=True, help="meta.json written by build_index.py")
    ap.add_argument("--out", required=True, help="output prefix")
    ap.add_argument("--reps", type=int, help="warm repetitions (default from lab_config.json)")
    ap.add_argument("--cold-probe", type=int, help=argparse.SUPPRESS)
    ap.add_argument("--qcache", help=argparse.SUPPRESS)
    ap.add_argument("--cache", help=argparse.SUPPRESS)
    a = ap.parse_args()
    cfg = L.config()
    if a.cold_probe is not None:
        return cold_probe(a, cfg)

    meta = json.load(open(a.index_meta))
    reps = a.reps or cfg["retrieval"]["latency_reps"]
    t0 = time.perf_counter()
    emb = E.get(a.embedder, cfg, a.model_path)
    t_load = time.perf_counter() - t0
    if emb.name != meta["embedder"] and not a.model_path:
        sys.exit(f"index was built with {meta['embedder']}, client is using {emb.name}; they must match")
    Q = L.read_jsonl(L.path("data", "retrieval", "questions.jsonl"))
    t0 = time.perf_counter()
    QV = emb.encode([q["question"] for q in Q])
    t_embed = (time.perf_counter() - t0) / len(Q) * 1000

    cache = a.out + "_client_cache"
    os.makedirs(cache, exist_ok=True)
    qcache = os.path.join(cache, "query_embeddings.npy")
    np.save(qcache, QV)

    d = Design(a.design, cfg, cache)
    t0 = time.perf_counter()
    setup_bytes = d.setup()
    setup_ms = (time.perf_counter() - t0) * 1000
    d.load_local()

    # scoring pass, with transfer accounting
    s0, r0 = d.bytes_total()
    rows = []
    for q, v in zip(Q, QV):
        got = d.query(v)
        rel = set(q["relevant"])
        rank = next((i + 1 for i, x in enumerate(got) if x in rel), "")
        rows.append({"id": q["id"], "hit_at_5": int(bool(rank)), "first_relevant_rank": rank, "top5": " ".join(got),
                     "relevant": " ".join(q["relevant"])})
    s1, r1 = d.bytes_total()
    per_q_sent, per_q_recv = (s1 - s0) / len(Q), (r1 - r0) / len(Q)

    # warm latency
    warm = []
    for _ in range(reps):
        for v in QV:
            t = time.perf_counter()
            d.query(v)
            warm.append((time.perf_counter() - t) * 1000)

    # cold latency: a fresh process per probe, timing local loading plus the first query
    cold = []
    for i in range(reps):
        out = subprocess.run([sys.executable, __file__, "--design", a.design, "--embedder", a.embedder, "--index-meta", a.index_meta,
                              "--out", a.out, "--cold-probe", str(i % len(Q)), "--qcache", qcache, "--cache", cache],
                             capture_output=True, text=True, check=True)
        cold.append(json.loads(out.stdout.strip().splitlines()[-1])["cold_ms"])

    L.write_csv(a.out + "_ledger.csv", rows, ["id", "hit_at_5", "first_relevant_rank", "top5", "relevant"])
    m = {"design": a.design, "embedder": emb.name, "pipeline_test_only": a.embedder == "hashing", "n_questions": len(Q),
         "hits": sum(r["hit_at_5"] for r in rows), "setup_bytes": setup_bytes, "setup_ms": round(setup_ms, 1),
         "per_query_bytes_sent": round(per_q_sent, 1), "per_query_bytes_received": round(per_q_recv, 1),
         "warm_ms": {"median": round(L.percentile(warm, 0.5), 3), "p95": round(L.percentile(warm, 0.95), 3), "n": len(warm)},
         "cold_ms": {"median": round(L.percentile(cold, 0.5), 3), "p95": round(L.percentile(cold, 0.95), 3), "n": len(cold)},
         "embedder_load_s": round(t_load, 2), "embed_ms_per_query": round(t_embed, 3), "reps": reps, "host": L.host_record()}
    json.dump(m, open(a.out + "_measure.json", "w"), indent=2)
    print(json.dumps({k: m[k] for k in ("design", "hits", "setup_bytes", "per_query_bytes_received", "warm_ms", "cold_ms")}))


if __name__ == "__main__":
    main()
