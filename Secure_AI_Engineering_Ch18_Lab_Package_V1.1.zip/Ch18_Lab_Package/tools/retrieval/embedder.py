"""Embedding backends for the retrieval comparison.

  st       sentence-transformers model named in lab_config.json (the predeclared
           embedder; use it for every reported result)
  hashing  feature-hashed unigrams and bigrams, 384 dimensions. Offline and
           dependency-free apart from numpy. It is NOT a semantic embedding and
           exists only so the pipeline can be tested without downloading a model.
"""
import hashlib
import math
import re

import numpy as np

DIM_HASH = 384
_TOK = re.compile(r"[a-z0-9]+")


class HashingEmbedder:
    name = "hashing-unigram-bigram-384"
    revision = "builtin"
    dim = DIM_HASH

    def encode(self, texts):
        out = np.zeros((len(texts), self.dim), dtype=np.float32)
        for r, t in enumerate(texts):
            toks = _TOK.findall(t.lower())
            feats = toks + [a + "_" + b for a, b in zip(toks, toks[1:])]
            counts = {}
            for f in feats:
                counts[f] = counts.get(f, 0) + 1
            for f, c in counts.items():
                h = hashlib.blake2b(f.encode(), digest_size=8).digest()
                idx = int.from_bytes(h[:4], "little") % self.dim
                sign = 1.0 if h[4] & 1 else -1.0
                out[r, idx] += sign * (1 + math.log(c))
            n = np.linalg.norm(out[r])
            if n > 0:
                out[r] /= n
        return out


class STEmbedder:
    def __init__(self, model_name_or_path, revision=None):
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as e:
            raise SystemExit("sentence-transformers is not installed. Install it (pip install sentence-transformers) and "
                             "download the model named in lab_config.json, or use --embedder hashing for a pipeline test only.") from e
        self.model = SentenceTransformer(model_name_or_path, revision=revision) if revision else SentenceTransformer(model_name_or_path)
        self.name = model_name_or_path
        self.revision = revision or "unrecorded"
        self.dim = self.model.get_sentence_embedding_dimension()

    def encode(self, texts):
        return np.asarray(self.model.encode(list(texts), normalize_embeddings=True, batch_size=32, show_progress_bar=False),
                          dtype=np.float32)


def get(backend, cfg, model_path=None):
    if backend == "hashing":
        return HashingEmbedder()
    if backend == "st":
        rev = cfg["retrieval"].get("embedding_model_revision")
        rev = None if (not rev or rev.startswith("FILL")) else rev
        return STEmbedder(model_path or cfg["retrieval"]["embedding_model"], rev if not model_path else None)
    raise SystemExit(f"unknown embedder {backend}")


def passage_text(p):
    return f"{p['doc_title']}: {p['heading']}. {p['text']}"
