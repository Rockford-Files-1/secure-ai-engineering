#!/usr/bin/env python3
"""Assemble the retrieval comparison in the form of Chapter 18, Table 18.8.

Usage:
  python3 tools/retrieval/compare_retrieval.py --prefix results/retrieval --designs a b c \
      --service-log results/service_log.jsonl --out results/retrieval_comparison.md

Hit@5 is binary per question, so Wilson intervals apply, and paired comparisons
against design (a) use Newcombe's method 10, the package's predeclared method.
"""
import argparse
import csv
import json
import os
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import labstats as S


def pts(x):
    v = round(100 * x, 1)
    return f"{v + 0.0:+.1f}"

NAMES = {"a": "(a) Server-side retrieval", "b": "(b) Cluster download", "c": "(c) Full-index download", "pir": "(b') Cluster by two-server PIR"}


def kb(x):
    return f"{x/1024:.1f} KB" if x < 1024 * 1024 else f"{x/1024/1024:.2f} MB"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prefix", required=True)
    ap.add_argument("--designs", nargs="+", default=["a", "b", "c"])
    ap.add_argument("--service-log", required=True)
    ap.add_argument("--pir-logs", nargs="*", default=[])
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    L, M = {}, {}
    for d in a.designs:
        with open(f"{a.prefix}_{d}_ledger.csv", newline="") as f:
            L[d] = {r["id"]: int(r["hit_at_5"]) for r in csv.DictReader(f)}
        M[d] = json.load(open(f"{a.prefix}_{d}_measure.json"))
    test_only = any(m["pipeline_test_only"] for m in M.values())
    lines = ["# Retrieval comparison", ""]
    if test_only:
        lines += ["**PIPELINE TEST ONLY: built with the hashing embedder. These numbers must not be reported.**", ""]
    lines += ["| Design | Hit@5 (n) [Wilson] | Paired vs (a), points [Newcombe 10] | Setup | Warm median / p95 | Cold median | Per-query transfer (received) | What the service learns |",
              "|---|---|---|---|---|---|---|---|"]
    learns = {"a": "The full query embedding, which can be inverted to approximate text, and the results",
              "b": "Which cluster the query fell in", "c": "That the client downloaded the index",
              "pir": "Random-looking bit vectors; the cluster only if both servers collude"}
    for d in a.designs:
        n = len(L[d])
        k = sum(L[d].values())
        lo, hi = S.wilson(k, n)
        pair = "—"
        if d != "a" and "a" in L:
            A, B, C, D = S.paired_table(L["a"], L[d])
            diff, plo, phi = S.newcombe10(A, B, C, D)
            pair = f"{pts(diff)} [{pts(plo)}, {pts(phi)}] ({B} lost, {C} gained)"
        m = M[d]
        setup = "None" if not m["setup_bytes"] else f"{kb(m['setup_bytes'])}, {m['setup_ms']:.0f} ms"
        lines.append(f"| {NAMES[d]} | {k} ({S.pct(k/n)}%) [{S.pct(lo)}, {S.pct(hi)}] | {pair} | {setup} | "
                     f"{m['warm_ms']['median']:.2f} / {m['warm_ms']['p95']:.2f} ms | {m['cold_ms']['median']:.1f} ms | "
                     f"{kb(m['per_query_bytes_received'])} | {learns[d]} |")
    # amortization
    if "c" in M:
        full = M["c"]["setup_bytes"]
        lines += ["", "Amortization of the full-index download:"]
        for d in ("a", "b"):
            if d in M and M[d]["per_query_bytes_received"] > 0:
                lines.append(f"- Below {NAMES[d]}'s per-query transfer ({kb(M[d]['per_query_bytes_received'])}) after about "
                             f"{full / M[d]['per_query_bytes_received']:.0f} queries.")
    # service log summary
    ent = [json.loads(l) for l in open(a.service_log) if l.strip()]
    c = Counter(e["path"].split("/")[1] if e["path"].startswith("/cluster") else e["path"] for e in ent)
    lines += ["", f"Service log: {len(ent)} requests: " + ", ".join(f"{k} {v}" for k, v in sorted(c.items()))]
    ex = next((e for e in ent if e["path"] == "/search"), None)
    if ex:
        v = ex["received_embedding"]
        lines.append(f"- Example /search entry: received a {len(v)}-dimension embedding beginning "
                     f"[{', '.join(f'{x:.4f}' for x in v[:4])}, ...]; {ex['learned']}.")
    clusters = Counter(e["path"] for e in ent if e["path"].startswith("/cluster"))
    if clusters:
        lines.append("- Cluster requests by cluster: " + ", ".join(f"{k.rsplit('/',1)[1]}: {v}" for k, v in sorted(clusters.items())))
    for p in a.pir_logs:
        pe = [json.loads(l) for l in open(p) if l.strip()]
        lines.append(f"- {os.path.basename(p)}: {len(pe)} requests, each a bit vector such as {pe[0]['received_bits'] if pe else ''}")
    lines += ["", "Each design's per-question ledger is in its _ledger.csv file so paired intervals can be reproduced."]
    with open(a.out, "w") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
