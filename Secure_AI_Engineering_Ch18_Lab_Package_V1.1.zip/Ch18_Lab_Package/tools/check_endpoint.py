#!/usr/bin/env python3
"""Check that the inference runtime is reachable only from the host itself.

Usage (runtime running):
  python3 tools/check_endpoint.py --port 8080 --record results/endpoint_check.json                    # sockets + same-host checks
  sudo python3 tools/check_endpoint.py --port 8080 --netns --record results/endpoint_check.json       # Linux: separate namespace
  python3 tools/check_endpoint.py --port 8080 --docker python:3.12-slim --record results/endpoint_check.json   # bridged container
  python3 tools/check_endpoint.py --port 8080 --from-remote --record results/endpoint_check_remote.json        # run ON the second host,
                                                                                         # with --target <lab host IP>

What counts as evidence:
  * The listening-socket listing shows the bind address (127.0.0.1 is what you want; 0.0.0.0 or :: is not).
  * A connection attempt from a genuinely separate network namespace must fail. A container started with
    --network host shares the host's networking and does NOT count; this tool uses a bridged network.
  * Connecting from the host to its own LAN address is a useful extra check but is not a separate namespace.
"""
import argparse
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
import time


def run(cmd):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        return r.returncode, (r.stdout + r.stderr).strip()
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        return -1, str(e)


def listing(port):
    sysname = platform.system()
    if sysname == "Linux" and shutil.which("ss"):
        cmd = ["ss", "-ltnp"]
    elif shutil.which("lsof"):
        cmd = ["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN"]
    else:
        cmd = ["netstat", "-an"] if sysname != "Windows" else ["netstat", "-ano", "-p", "TCP"]
    code, out = run(cmd)
    lines = [l for l in out.splitlines() if f":{port}" in l or f".{port} " in l or "LISTEN" in l and str(port) in l]
    return {"command": " ".join(cmd), "matching_lines": lines}


def try_connect(host, port, timeout=3):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((host, port))
        return "CONNECTED"
    except ConnectionRefusedError:
        return "refused"
    except socket.timeout:
        return "timed out"
    except OSError as e:
        return f"error: {e}"
    finally:
        s.close()


def lan_address():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("192.0.2.1", 9))       # TEST-NET address; no packet is sent for a UDP connect
        return s.getsockname()[0]
    except OSError:
        return None
    finally:
        s.close()


PROBE = "import socket,sys\ns=socket.socket();s.settimeout(3)\ntry:\n s.connect((sys.argv[1],int(sys.argv[2])));print('CONNECTED')\nexcept ConnectionRefusedError:print('refused')\nexcept Exception as e:print('error:',e)"


def netns_test(port):
    if os.geteuid() != 0:
        return {"method": "netns", "result": "not run: requires root (sudo)"}
    ns, hv, nv = "ch18lab", "ch18h", "ch18n"
    steps = [["ip", "netns", "add", ns], ["ip", "link", "add", hv, "type", "veth", "peer", "name", nv],
             ["ip", "link", "set", nv, "netns", ns], ["ip", "addr", "add", "10.218.0.1/30", "dev", hv], ["ip", "link", "set", hv, "up"],
             ["ip", "netns", "exec", ns, "ip", "addr", "add", "10.218.0.2/30", "dev", nv],
             ["ip", "netns", "exec", ns, "ip", "link", "set", nv, "up"]]
    log = []
    try:
        for s in steps:
            c, o = run(s)
            log.append({"cmd": " ".join(s), "exit": c, "out": o})
            if c != 0:
                return {"method": "netns", "result": f"setup failed at: {' '.join(s)}", "log": log}
        c, o = run(["ip", "netns", "exec", ns, sys.executable, "-c", PROBE, "10.218.0.1", str(port)])
        return {"method": "netns", "target": f"10.218.0.1:{port} (host side of a veth pair)", "result": o, "log": log}
    finally:
        run(["ip", "link", "del", hv])
        run(["ip", "netns", "del", ns])


def docker_test(port, image):
    gw_code, gw = run(["docker", "network", "inspect", "bridge", "-f", "{{(index .IPAM.Config 0).Gateway}}"])
    target = gw.strip() if gw_code == 0 and gw.strip() else "172.17.0.1"
    c, o = run(["docker", "run", "--rm", "--network", "bridge", image, "python3", "-c", PROBE, target, str(port)])
    return {"method": f"docker bridged network ({image})", "target": f"{target}:{port} (host's bridge address)",
            "result": o.splitlines()[-1] if o else "", "exit": c}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--netns", action="store_true")
    ap.add_argument("--docker", metavar="IMAGE", help="a locally available image that has python3")
    ap.add_argument("--from-remote", action="store_true", help="run on a second host")
    ap.add_argument("--target", help="lab host address, with --from-remote")
    ap.add_argument("--record", required=True)
    a = ap.parse_args()
    rec = {"time": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "host": platform.node(), "port": a.port, "tests": []}
    if a.from_remote:
        if not a.target:
            sys.exit("--from-remote needs --target <lab host IP>")
        rec["tests"].append({"method": "second host", "target": f"{a.target}:{a.port}", "result": try_connect(a.target, a.port)})
    else:
        rec["listening"] = listing(a.port)
        rec["tests"].append({"method": "same host, loopback", "target": f"127.0.0.1:{a.port}", "result": try_connect("127.0.0.1", a.port),
                             "expect": "CONNECTED (the runtime is up)"})
        lan = lan_address()
        if lan:
            rec["tests"].append({"method": "same host, LAN address (not a separate namespace)", "target": f"{lan}:{a.port}",
                                 "result": try_connect(lan, a.port), "expect": "refused"})
        if a.netns:
            rec["tests"].append(netns_test(a.port))
        if a.docker:
            rec["tests"].append(docker_test(a.port, a.docker))
    external = [t for t in rec["tests"] if t["method"] not in ("same host, loopback",) and "not a separate" not in t["method"]]
    if not external:
        rec["verdict"] = "INCOMPLETE: no test from a separate namespace or host was run"
    elif any("CONNECTED" in t["result"] for t in external):
        rec["verdict"] = "EXPOSED: reachable from outside the host"
    elif all(t["result"] in ("refused", "timed out") or t["result"].startswith(("refused", "error")) for t in external):
        rec["verdict"] = "NOT REACHABLE from the separate namespace or host tested"
    else:
        rec["verdict"] = "INCONCLUSIVE: see test results"
    json.dump(rec, open(a.record, "w"), indent=2)
    print(json.dumps(rec, indent=2))


if __name__ == "__main__":
    main()
