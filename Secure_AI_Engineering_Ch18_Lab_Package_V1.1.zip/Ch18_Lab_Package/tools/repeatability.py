#!/usr/bin/env python3
"""Summarize repeatability across reruns of the 20-question subset.

Usage:
  python3 tools/repeatability.py results/rep_q4_run1.jsonl results/rep_q4_run2.jsonl results/rep_q4_run3.jsonl \
      --scored-run results/eval_q4.jsonl --out results/repeatability_q4.md

Reports, for each question, whether the response text was identical across all
runs (including the scoring run if given) and whether the correctness decision
was identical. Report the observed agreement; do not claim determinism.
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import labcommon as L
import score_eval as SE


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("runs", nargs="+")
    ap.add_argument("--scored-run", help="the full scoring run, whose subset responses are included in the comparison")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    key = {it["id"]: it for it in L.read_jsonl(L.path("data", "eval", "catalog_eval.jsonl"))}
    subset = open(L.path(L.config()["repeatability"]["subset_file"])).read().split()
    files = ([a.scored_run] if a.scored_run else []) + a.runs
    runs = []
    for f in files:
        d = {r["id"]: r["response"] for r in L.read_jsonl(f)}
        runs.append(d)
    lines = [f"# Repeatability over {len(subset)} questions and {len(files)} runs", "",
             "| Id | Critical | Identical text | Identical score | Scores by run |", "|---|---|---|---|---|"]
    same_text = same_score = 0
    for i in subset:
        texts = [r.get(i, "<missing>") for r in runs]
        scores = [SE.score(key[i], t)[0] if t != "<missing>" else None for t in texts]
        st, ss = len(set(texts)) == 1, len(set(scores)) == 1
        same_text += st
        same_score += ss
        lines.append(f"| {i} | {'yes' if key[i]['critical'] else ''} | {'yes' if st else 'NO'} | {'yes' if ss else 'NO'} | {' '.join(map(str, scores))} |")
    n = len(subset)
    lines += ["", f"Identical response text across all runs: {same_text}/{n}.",
              f"Identical correctness decision across all runs: {same_score}/{n}.",
              "Greedy decoding and a fixed seed reduce variation but do not guarantee identical output across hardware, runtime versions, or batch settings."]
    with open(a.out, "w") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines[-3:]))


if __name__ == "__main__":
    main()
