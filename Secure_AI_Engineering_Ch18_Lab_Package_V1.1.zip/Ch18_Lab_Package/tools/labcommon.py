"""Shared helpers for the Chapter 18 laboratory tools (standard library only)."""
import csv
import json
import os
import platform
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def path(*p):
    return os.path.join(ROOT, *p)


def config():
    with open(path("lab_config.json"), encoding="utf-8") as f:
        return json.load(f)


def read_jsonl(p):
    with open(p, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def write_jsonl(p, rows):
    os.makedirs(os.path.dirname(os.path.abspath(p)), exist_ok=True)
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n")


def read_ledger(p, key="correct"):
    with open(p, newline="", encoding="utf-8") as f:
        return {r["id"]: int(r[key]) for r in csv.DictReader(f)}, list(csv.DictReader(open(p, newline="", encoding="utf-8")))


def write_csv(p, rows, fields):
    os.makedirs(os.path.dirname(os.path.abspath(p)), exist_ok=True)
    with open(p, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fields})


def host_record():
    return {"python": sys.version.split()[0], "platform": platform.platform(), "machine": platform.machine(),
            "processor": platform.processor() or "unknown"}


def passages():
    return {p["passage_id"]: p for p in read_jsonl(path("data", "corpus", "passages.jsonl"))}


def percentile(xs, q):
    xs = sorted(xs)
    if not xs:
        return float("nan")
    i = (len(xs) - 1) * q
    lo, hi = int(i), min(int(i) + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (i - lo)
