#!/usr/bin/env python3
"""Load-time verification: check the model before the runtime is allowed to start.

This is the lab's version of the opening case's pre-departure check. It runs,
in order, and stops at the first failure:
  1. The signing key's fingerprint matches the expected value in lab_config.json.
  2. The OpenSSF model-signing verification of the model directory succeeds.
  3. Every file matches the release inventory (model/RELEASE_INVENTORY.json),
     which is inside the signed directory and therefore covered by the signature.
  4. The artifact about to be loaded is listed in that inventory.
  5. The launch command binds to loopback and enables the runtime's API key.
Then, with --exec, it starts the runtime.

Usage:
  python3 tools/load_gate.py --config q4 --record results/load_gate_q4.json
  python3 tools/load_gate.py --config q4 --record results/load_gate_q4.json --exec
  python3 tools/load_gate.py --config q4 --model-dir model_tampered/ --record results/load_gate_tampered.json

Students extend this procedure for primary artifact 3 (integrity controls).
"""
import argparse
import json
import os
import shlex
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
import hash_inventory as HI
import key_fingerprint as KF
import labcommon as L


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", choices=["full", "q4"], required=True)
    ap.add_argument("--model-dir", help="model directory to check (default: lab_config.json distribution_dir)")
    ap.add_argument("--public-key", default="keys/instructor_signing_pub.pem")
    ap.add_argument("--record", required=True)
    ap.add_argument("--exec", action="store_true", help="start the runtime if every check passes")
    ap.add_argument("--pipeline-test", action="store_true", help=argparse.SUPPRESS)
    a = ap.parse_args()
    cfg = L.config()
    m, rt = cfg["model"], cfg["runtime"]
    mdir = a.model_dir or L.path(m["distribution_dir"])
    rec = {"time": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "model_dir": os.path.abspath(mdir), "config": a.config, "checks": []}

    def done(ok, name, detail):
        rec["checks"].append({"check": name, "passed": ok, "detail": detail})
        print(f"{'PASS' if ok else 'FAIL'}  {name}: {detail}")
        if not ok:
            rec["result"] = "REFUSED"
            json.dump(rec, open(a.record, "w"), indent=2)
            sys.exit(1)

    # 1. key fingerprint
    expected = m["expected_signer_public_key_sha256"]
    fp = KF.fingerprint(L.path(a.public_key) if not os.path.isabs(a.public_key) else a.public_key)
    if expected.startswith("FILL"):
        done(a.pipeline_test, "signing key fingerprint", "no expected fingerprint in lab_config.json (instructor must fill it)")
    else:
        done(fp == expected, "signing key fingerprint", f"{fp[:16]}… {'matches' if fp == expected else 'does NOT match'} expected")

    # 2. signature
    if a.pipeline_test:
        done(True, "model signature", "SKIPPED in pipeline test; a real run must verify the signature")
    else:
        cmd = m["verify_command"].replace("model/", mdir.rstrip("/") + "/")
        try:
            r = subprocess.run(shlex.split(cmd), cwd=L.ROOT, capture_output=True, text=True)
            out = (r.stdout + r.stderr).strip().splitlines()
            done(r.returncode == 0, "model signature", f"`{cmd}` exited {r.returncode}: {out[-1] if out else ''}")
        except FileNotFoundError:
            done(False, "model signature", "model_signing is not installed; install the version named in lab_config.json")

    # 3. inventory
    inv_path = os.path.join(mdir, "RELEASE_INVENTORY.json")
    if not os.path.exists(inv_path):
        done(False, "release inventory", "RELEASE_INVENTORY.json missing from the model directory")
    ref = json.load(open(inv_path))["files"]
    cur = HI.inventory(mdir, {"RELEASE_INVENTORY.json"})
    bad = sorted(set(ref) ^ set(cur)) + sorted(f for f in set(ref) & set(cur) if ref[f]["sha256"] != cur[f]["sha256"])
    done(not bad, "release inventory", "all files match" if not bad else f"mismatched: {', '.join(bad)}")

    # 4. artifact listed
    art = m["full_precision_file"] if a.config == "full" else m["quantized_file"]
    rel = os.path.relpath(L.path(art), L.path(m["distribution_dir"])).replace(os.sep, "/")
    done(rel in ref, "artifact in inventory", f"{rel} {'listed' if rel in ref else 'NOT listed'}"
         + (f", sha256 {ref[rel]['sha256'][:16]}…" if rel in ref else ""))

    # 5. launch configuration
    launch = rt["launch_full_precision"] if a.config == "full" else rt["launch_quantized"]
    toks = shlex.split(launch)
    host = toks[toks.index("--host") + 1] if "--host" in toks else "(runtime default)"
    done(host in ("127.0.0.1", "::1", "localhost"), "loopback binding", f"--host {host}")
    done("--api-key" in toks and bool(os.environ.get(rt["api_key_env"])) or a.pipeline_test, "runtime authentication",
         f"--api-key present: {'--api-key' in toks}; {rt['api_key_env']} set: {bool(os.environ.get(rt['api_key_env']))}")

    rec["result"] = "PIPELINE TEST" if a.pipeline_test else "ALLOWED"
    rec["artifact"] = {"path": rel, "sha256": ref[rel]["sha256"]}
    rec["launch"] = launch
    json.dump(rec, open(a.record, "w"), indent=2)
    print(f"RESULT: {rec['result']}")
    if a.exec and not a.pipeline_test:
        os.execvp(toks[0], [t.replace("$" + rt["api_key_env"], os.environ[rt["api_key_env"]]) for t in toks])


if __name__ == "__main__":
    main()
