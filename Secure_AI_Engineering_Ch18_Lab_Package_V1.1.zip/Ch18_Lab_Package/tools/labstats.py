#!/usr/bin/env python3
"""Statistics for the Chapter 18 laboratory (standard library only).

Implements the methods the package predeclares:
  wilson(k, n)                      Wilson score interval for one proportion
  newcombe10(a, b, c, d)            Newcombe (1998) method 10 for a paired difference,
                                    with the continuity-corrected phi used in the
                                    Appendix A, Section A.1 (Supplementary Mathematics)
  mcnemar_exact(b, c)               two-sided exact McNemar p-value
  margin_decision(lo, margin, hi)   Chapter 13 criterion status (pass, fail, inconclusive)

Paired table convention (first configuration = reference, second = candidate):
  a = both correct, b = reference correct only (regressions),
  c = candidate correct only (improvements), d = both wrong.
The difference reported is candidate minus reference, in proportion units.

Command line self-check:  python3 labstats.py --selftest
"""
import math
import sys

Z95 = 1.959963984540054


def wilson(k, n, z=Z95):
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, centre - half), min(1.0, centre + half))


def newcombe10(a, b, c, d, z=Z95):
    """Return (diff, lo, hi) for candidate minus reference."""
    n = a + b + c + d
    if n == 0:
        raise ValueError("empty table")
    p1 = (a + b) / n          # reference correct
    p2 = (a + c) / n          # candidate correct
    l1, u1 = wilson(a + b, n, z)
    l2, u2 = wilson(a + c, n, z)
    # phi with continuity correction (Newcombe 1998, method 10)
    num = a * d - b * c
    if num > 0:
        num = max(num - n / 2, 0)
    den = math.sqrt((a + b) * (c + d) * (a + c) * (b + d))
    phi = num / den if den > 0 else 0.0
    # interval for theta = p1 - p2
    dl = math.sqrt(max((p1 - l1) ** 2 - 2 * phi * (p1 - l1) * (u2 - p2) + (u2 - p2) ** 2, 0))
    du = math.sqrt(max((u1 - p1) ** 2 - 2 * phi * (u1 - p1) * (p2 - l2) + (p2 - l2) ** 2, 0))
    theta = p1 - p2
    lo, hi = theta - dl, theta + du
    # negate to express as candidate minus reference
    return (-theta, -hi, -lo)


def mcnemar_exact(b, c):
    m = b + c
    if m == 0:
        return 1.0
    k = min(b, c)
    tail = sum(math.comb(m, i) for i in range(k + 1)) / 2 ** m
    return min(1.0, 2 * tail)


def margin_decision(lo, margin, hi=None):
    """Criterion status for a non-inferiority margin, following Chapter 13 (proportion units).

    pass: the whole interval lies above -margin; fail: the whole interval lies below -margin;
    inconclusive: the interval spans -margin. Without hi, only pass versus not-pass can be decided.
    """
    if lo > -margin:
        return "pass: preservation established"
    if hi is not None and hi < -margin:
        return "fail: decline beyond the margin established"
    if hi is None:
        return "not pass: more evaluation required"
    return "inconclusive: interval spans the margin; more evaluation required"


def paired_table(ref, cand):
    """ref, cand: dict id -> 0/1 over the same ids."""
    if set(ref) != set(cand):
        missing = sorted(set(ref) ^ set(cand))[:5]
        raise ValueError(f"ledgers cover different questions, e.g. {missing}")
    a = b = c = d = 0
    for k in ref:
        r, x = ref[k], cand[k]
        if r and x:
            a += 1
        elif r and not x:
            b += 1
        elif x and not r:
            c += 1
        else:
            d += 1
    return a, b, c, d


def pct(x):
    return f"{100 * x:.1f}"


def _selftest():
    ok = True

    def check(label, got, want, tol=0.0006):
        nonlocal ok
        good = all(abs(g - w) <= tol for g, w in zip(got, want))
        ok &= good
        print(f"{'PASS' if good else 'FAIL'}  {label}: got {[round(g, 4) for g in got]} want {want}")

    # Chapter 18 Table 18.4 (approved 262/300)
    check("Table 18.4 community 4-bit (17 regressions, 6 improvements)",
          newcombe10(245, 17, 6, 32)[1:], [-0.0702, -0.0047])
    check("Table 18.4 in-house 4-bit (5 regressions, 2 improvements)",
          newcombe10(257, 5, 2, 36)[1:], [-0.0310, 0.0101])
    # Chapter 18 Table 18.8, design (b) vs (a): 171 vs 163 of 200, 9 lost and 1 gained
    check("Table 18.8 cluster vs server-side (9 lost, 1 gained)",
          newcombe10(162, 9, 1, 28)[1:], [-0.0755, -0.0073])
    check("Wilson 262/300", wilson(262, 300), [0.831, 0.906], tol=0.0006)
    check("Wilson 31/40", wilson(31, 40), [0.625, 0.877], tol=0.0006)
    p = mcnemar_exact(17, 6)
    print(f"INFO  exact McNemar 17 vs 6: p = {p:.4f}")
    print("selftest", "PASSED" if ok else "FAILED")
    return ok


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(0 if _selftest() else 1)
    print(__doc__)
