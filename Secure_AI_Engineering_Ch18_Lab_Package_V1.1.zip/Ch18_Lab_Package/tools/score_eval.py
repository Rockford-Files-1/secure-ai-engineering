#!/usr/bin/env python3
"""Score evaluation responses against the answer key and write a per-question ledger.

Usage:
  python3 tools/score_eval.py results/eval_full.jsonl --ledger results/ledger_full.csv

Scoring follows lab_config.json "scoring": a response is correct only if it gives
exactly one answer of the expected type and that answer matches the key. The
ledger records what was extracted so every decision can be checked by hand.
"""
import argparse
import os
import re
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(__file__))
import labcommon as L

UNITS = "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split()
TENS = {"twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90}
ORD = {"first": 1, "second": 2, "third": 3, "fourth": 4, "fifth": 5, "sixth": 6, "seventh": 7, "eighth": 8, "ninth": 9, "tenth": 10,
       "eleventh": 11, "twelfth": 12, "fifteenth": 15, "twentieth": 20, "thirtieth": 30}
WORDNUM = {w: i for i, w in enumerate(UNITS)}
WORDNUM.update(TENS)
WORDNUM.update(ORD)
WORDNUM["hundred"] = 100

CAT = re.compile(r"\b(20\d{2})\s*[-‐-―/]\s*((?:20)?\d{2})\b")
CODE = re.compile(r"\b([A-Za-z]{2,4})\s*-?\s*(\d{3})\b")
NUM = re.compile(r"(?<![\w.])(\d+(?:\.\d+)?)(?:st|nd|rd|th)?\b")


def norm(s):
    s = s.lower().replace("–", "-").replace("—", "-")
    return " ".join(re.sub(r"[^a-z0-9.\- ]", " ", s).split())


def catalogs(text):
    out = set()
    for a, b in CAT.findall(text):
        y1 = int(a)
        y2 = int(b) if len(b) == 4 else int(a[:2] + b)
        if y2 == y1 + 1:
            out.add(f"{y1}-{str(y2)[2:]}")
    return out


def numbers(text):
    t = CAT.sub(" ", text)          # catalog years are not numeric answers
    t = CODE.sub(" ", t)            # nor are course codes
    vals = {float(x) for x in NUM.findall(t)}
    words = re.findall(r"[a-z]+(?:-[a-z]+)?", t.lower())
    for w in words:
        if "-" in w:
            a, b = w.split("-", 1)
            if a in TENS and b in WORDNUM and WORDNUM[b] < 10:
                vals.add(float(TENS[a] + WORDNUM[b]))
                continue
        if w in WORDNUM and w not in ("second", "first"):   # "first"/"second" are rarely numeric answers here
            vals.add(float(WORDNUM[w]))
    if "percent" in t.lower() or "%" in t:
        pass
    return vals


def score(item, response):
    t = item["answer_type"]
    r = response.strip()
    if not r:
        return 0, "", "empty response"
    if t == "yesno":
        first = norm(r).split(" ")[0] if norm(r) else ""
        ok = first in ("yes", "no") and first == item["answer"]
        return int(ok), first, "" if first in ("yes", "no") else "no yes/no answer"
    if t == "catalog":
        found = catalogs(r)
        if len(found) != 1:
            return 0, ";".join(sorted(found)), f"{len(found)} catalog years found"
        got = found.pop()
        return int(got == item["answer"]), got, ""
    if t == "code":
        found = {f"{a.upper()} {b}" for a, b in CODE.findall(r)}
        if len(found) != 1:
            return 0, ";".join(sorted(found)), f"{len(found)} course codes found"
        got = found.pop()
        return int(got == item["answer"]), got, ""
    if t == "num":
        found = numbers(r)
        if len(found) != 1:
            return 0, ";".join(f"{x:g}" for x in sorted(found)), f"{len(found)} numbers found"
        got = found.pop()
        return int(abs(got - float(item["answer"])) < 1e-9), f"{got:g}", ""
    if t == "term":
        nr = norm(r)
        if len(nr.split()) > 12:
            return 0, nr[:60], "longer than 12 words"
        hit = next((a for a in item["accept"] if norm(a) in nr), None)
        return int(hit is not None), hit or nr[:60], ""
    raise ValueError(t)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("responses")
    ap.add_argument("--ledger", required=True)
    a = ap.parse_args()
    key = {it["id"]: it for it in L.read_jsonl(L.path("data", "eval", "catalog_eval.jsonl"))}
    rows = []
    for r in L.read_jsonl(a.responses):
        it = key[r["id"]]
        ok, got, note = score(it, r["response"])
        rows.append({"id": r["id"], "category": it["category"], "critical": int(it["critical"]), "answer_type": it["answer_type"],
                     "expected": it["answer_display"], "extracted": got, "correct": ok, "note": note or r.get("error", ""),
                     "response": r["response"].replace("\n", " ")[:200]})
    L.write_csv(a.ledger, rows, ["id", "category", "critical", "answer_type", "expected", "extracted", "correct", "note", "response"])
    n = len(rows)
    k = sum(r["correct"] for r in rows)
    c = [r for r in rows if r["critical"]]
    print(f"{a.responses}: {k}/{n} correct; catalog-year {sum(r['correct'] for r in c)}/{len(c)}")
    print("notes:", dict(Counter(r["note"] for r in rows if r["note"])))


if __name__ == "__main__":
    main()
