#!/usr/bin/env python3
"""Record and compare SHA-256 hashes of every file in a model directory.

Usage:
  python3 tools/hash_inventory.py create model/ --out results/inventory_model.json
  python3 tools/hash_inventory.py compare model/RELEASE_INVENTORY.json model_tampered/

compare exits with status 1 and lists every added, missing, or changed file.
A hash inventory shows whether files changed; only the signature shows who
vouched for them. Use both.
"""
import argparse
import hashlib
import json
import os
import sys
import time

SKIP = {".DS_Store"}


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def inventory(root, exclude=()):
    files = {}
    for d, _, fs in os.walk(root):
        for f in sorted(fs):
            if f in SKIP:
                continue
            p = os.path.join(d, f)
            rel = os.path.relpath(p, root).replace(os.sep, "/")
            if rel in exclude:
                continue
            files[rel] = {"sha256": sha256(p), "bytes": os.path.getsize(p)}
    return dict(sorted(files.items()))


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("create")
    c.add_argument("dir")
    c.add_argument("--out", required=True)
    c.add_argument("--exclude", nargs="*", default=["RELEASE_INVENTORY.json"])
    k = sub.add_parser("compare")
    k.add_argument("inventory")
    k.add_argument("dir")
    a = ap.parse_args()
    if a.cmd == "create":
        inv = {"created": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "root": os.path.basename(os.path.abspath(a.dir)),
               "algorithm": "SHA-256", "files": inventory(a.dir, set(a.exclude))}
        with open(a.out, "w") as f:
            json.dump(inv, f, indent=2)
        print(f"{len(inv['files'])} files recorded in {a.out}")
        return
    ref = json.load(open(a.inventory))["files"]
    cur = inventory(a.dir, {"RELEASE_INVENTORY.json"})
    added = sorted(set(cur) - set(ref))
    missing = sorted(set(ref) - set(cur))
    changed = sorted(f for f in set(ref) & set(cur) if ref[f]["sha256"] != cur[f]["sha256"])
    for label, xs in (("ADDED", added), ("MISSING", missing), ("CHANGED", changed)):
        for f in xs:
            extra = f"  expected {ref[f]['sha256'][:16]}… got {cur[f]['sha256'][:16]}…" if label == "CHANGED" else ""
            print(f"{label:8} {f}{extra}")
    if added or missing or changed:
        print("RESULT: does not match the inventory")
        sys.exit(1)
    print(f"RESULT: all {len(ref)} files match")


if __name__ == "__main__":
    main()
